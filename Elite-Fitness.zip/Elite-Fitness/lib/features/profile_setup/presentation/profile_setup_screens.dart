import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/custom_button.dart';
import '../../../core/providers/state_providers.dart';

// Helper custom card for selection pages
class SelectionCard extends StatelessWidget {
  final String title;
  final String description;
  final bool isSelected;
  final VoidCallback onTap;
  final IconData? icon;

  const SelectionCard({
    super.key,
    required this.title,
    required this.description,
    required this.isSelected,
    required this.onTap,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSelected
              ? AppColors.primary
              : (isDark
                    ? AppColors.glassBorderDark
                    : AppColors.glassBorderLight),
          width: isSelected ? 2 : 1.5,
        ),
        gradient: isSelected
            ? LinearGradient(
                colors: [
                  AppColors.primary.withValues(alpha: 0.15),
                  AppColors.secondary.withValues(alpha: 0.08),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: isSelected
            ? null
            : (isDark ? AppColors.darkSurface : AppColors.lightSurface),
      ),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 12,
        ),
        leading: icon != null
            ? Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected
                      ? AppColors.primary.withValues(alpha: 0.2)
                      : Colors.grey.withValues(alpha: 0.1),
                ),
                child: Icon(
                  icon,
                  color: isSelected ? AppColors.secondary : Colors.grey,
                ),
              )
            : null,
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4.0),
          child: Text(
            description,
            style: TextStyle(
              color: isSelected
                  ? Theme.of(context).textTheme.bodyMedium?.color
                  : Theme.of(context).hintColor,
              fontSize: 13,
            ),
          ),
        ),
        trailing: Icon(
          isSelected ? Icons.check_circle : Icons.circle_outlined,
          color: isSelected ? AppColors.primary : Colors.grey,
        ),
      ),
    );
  }
}

// 9. Personal Information Screen
class PersonalInfoScreen extends ConsumerStatefulWidget {
  const PersonalInfoScreen({super.key});

  @override
  ConsumerState<PersonalInfoScreen> createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends ConsumerState<PersonalInfoScreen> {
  final _nameController = TextEditingController(text: "Alex Mercer");
  String _gender = "Male";
  double _age = 26;
  double _height = 180;
  double _weight = 75;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Personal Info",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Outfit',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Tell us about yourself to tailor your AI algorithms.",
                style: TextStyle(color: textSecondary),
              ),
              const SizedBox(height: 30),
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: "Your Name",
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                "Gender",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 12),
              Row(
                children: ["Male", "Female", "Other"].map((g) {
                  final isSelected = _gender == g;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() => _gender = g),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primary
                              : Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? AppColors.secondary
                                : Colors.transparent,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            g,
                            style: TextStyle(
                              color: isSelected ? Colors.white : textSecondary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Age",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    "${_age.toInt()} yrs",
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Slider(
                value: _age,
                min: 16,
                max: 100,
                activeColor: AppColors.primary,
                inactiveColor: Theme.of(context).cardColor,
                onChanged: (val) => setState(() => _age = val),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Height",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    "${_height.toInt()} cm",
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Slider(
                value: _height,
                min: 120,
                max: 220,
                activeColor: AppColors.primary,
                inactiveColor: Theme.of(context).cardColor,
                onChanged: (val) => setState(() => _height = val),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Weight",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    "${_weight.toInt()} kg",
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Slider(
                value: _weight,
                min: 40,
                max: 150,
                activeColor: AppColors.primary,
                inactiveColor: Theme.of(context).cardColor,
                onChanged: (val) => setState(() => _weight = val),
              ),
              const SizedBox(height: 40),
              CustomButton(
                text: "Continue",
                onPressed: () {
                  final profile = ref.read(userProfileProvider);
                  ref
                      .read(userProfileProvider.notifier)
                      .updateProfile(
                        profile.copyWith(
                          name: _nameController.text,
                          gender: _gender,
                          age: _age.toInt(),
                          height: _height,
                          weight: _weight,
                        ),
                      );
                  context.push('/profile-setup-goal');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 10. Fitness Goal Screen
class FitnessGoalScreen extends ConsumerStatefulWidget {
  const FitnessGoalScreen({super.key});

  @override
  ConsumerState<FitnessGoalScreen> createState() => _FitnessGoalScreenState();
}

class _FitnessGoalScreenState extends ConsumerState<FitnessGoalScreen> {
  String _selectedGoal = "Muscle Gain";

  final List<Map<String, String>> _goals = [
    {
      "title": "Weight Loss",
      "desc": "Burn fat, sculpt muscles, and improve cardiovascular health.",
    },
    {
      "title": "Muscle Gain",
      "desc": "Focus on hypertrophy workouts and dynamic strength development.",
    },
    {
      "title": "Strength",
      "desc": "Incorporate low rep compound lifts for maximum physical output.",
    },
    {
      "title": "Endurance",
      "desc": "Increase aerobic threshold and training duration parameters.",
    },
    {
      "title": "Athletic Performance",
      "desc": "Improve agility, plyometrics, and explosive core mechanics.",
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Your Main Goal",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Select your primary focus. We will configure your workout recommendations.",
              style: TextStyle(color: textSecondary),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: ListView.builder(
                itemCount: _goals.length,
                itemBuilder: (context, index) {
                  final g = _goals[index];
                  final isSelected = _selectedGoal == g["title"];
                  return SelectionCard(
                    title: g["title"]!,
                    description: g["desc"]!,
                    isSelected: isSelected,
                    onTap: () => setState(() => _selectedGoal = g["title"]!),
                  );
                },
              ),
            ),
            CustomButton(
              text: "Continue",
              onPressed: () {
                final profile = ref.read(userProfileProvider);
                ref
                    .read(userProfileProvider.notifier)
                    .updateProfile(profile.copyWith(goal: _selectedGoal));
                context.push('/profile-setup-activity');
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 11. Activity Level Screen
class ActivityLevelScreen extends ConsumerStatefulWidget {
  const ActivityLevelScreen({super.key});

  @override
  ConsumerState<ActivityLevelScreen> createState() =>
      _ActivityLevelScreenState();
}

class _ActivityLevelScreenState extends ConsumerState<ActivityLevelScreen> {
  String _activityLevel = "Moderately Active";

  final List<Map<String, String>> _levels = [
    {
      "title": "Sedentary",
      "desc": "Little or no exercise. Desk-bound routines.",
    },
    {
      "title": "Lightly Active",
      "desc": "Light physical tasks, light exercise 1-3 days/week.",
    },
    {
      "title": "Moderately Active",
      "desc": "Active daily tasks, moderate training 3-5 days/week.",
    },
    {
      "title": "Very Active",
      "desc": "Heavy daily exertion, intense sports/gym 6-7 days/week.",
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Activity Level",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Let us know how active you are to calculate your baseline energy expenditure.",
              style: TextStyle(color: textSecondary),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: ListView.builder(
                itemCount: _levels.length,
                itemBuilder: (context, index) {
                  final level = _levels[index];
                  final isSelected = _activityLevel == level["title"];
                  return SelectionCard(
                    title: level["title"]!,
                    description: level["desc"]!,
                    isSelected: isSelected,
                    icon: Icons.bolt,
                    onTap: () =>
                        setState(() => _activityLevel = level["title"]!),
                  );
                },
              ),
            ),
            CustomButton(
              text: "Continue",
              onPressed: () {
                final profile = ref.read(userProfileProvider);
                ref
                    .read(userProfileProvider.notifier)
                    .updateProfile(
                      profile.copyWith(activityLevel: _activityLevel),
                    );
                context.push('/profile-setup-health');
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 12. Health Conditions Screen
class HealthConditionsScreen extends ConsumerStatefulWidget {
  const HealthConditionsScreen({super.key});

  @override
  ConsumerState<HealthConditionsScreen> createState() =>
      _HealthConditionsScreenState();
}

class _HealthConditionsScreenState
    extends ConsumerState<HealthConditionsScreen> {
  final List<String> _selectedConditions = [];

  final List<String> _conditions = [
    "Knee Pain",
    "Lower Back Stiffness",
    "Shoulder Impingement",
    "Asthma / Respiratory",
    "Hypertension",
    "Diabetes",
    "Heart Condition",
    "None of the above",
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Health Limits",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Select any existing physical constraints so the AI Coach can adjust exercise selections safely.",
              style: TextStyle(color: textSecondary),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: Wrap(
                spacing: 12,
                runSpacing: 16,
                children: _conditions.map((condition) {
                  final isSelected = _selectedConditions.contains(condition);
                  return FilterChip(
                    label: Text(condition),
                    selected: isSelected,
                    selectedColor: AppColors.primary.withValues(alpha: 0.3),
                    checkmarkColor: AppColors.secondary,
                    onSelected: (selected) {
                      setState(() {
                        if (condition == "None of the above") {
                          _selectedConditions.clear();
                          _selectedConditions.add(condition);
                        } else {
                          _selectedConditions.remove("None of the above");
                          if (selected) {
                            _selectedConditions.add(condition);
                          } else {
                            _selectedConditions.remove(condition);
                          }
                        }
                      });
                    },
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.glassBorderDark,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            CustomButton(
              text: "Continue",
              onPressed: () {
                final profile = ref.read(userProfileProvider);
                ref
                    .read(userProfileProvider.notifier)
                    .updateProfile(
                      profile.copyWith(healthConditions: _selectedConditions),
                    );
                context.push('/profile-setup-target');
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 13. Target Body Areas Screen
class TargetBodyAreasScreen extends ConsumerStatefulWidget {
  const TargetBodyAreasScreen({super.key});

  @override
  ConsumerState<TargetBodyAreasScreen> createState() =>
      _TargetBodyAreasScreenState();
}

class _TargetBodyAreasScreenState extends ConsumerState<TargetBodyAreasScreen> {
  final List<String> _targetAreas = [];

  final List<String> _muscles = [
    "Chest",
    "Shoulders",
    "Back (Lats)",
    "Biceps & Triceps",
    "Core / Abs",
    "Quads & Hamstrings",
    "Glutes",
    "Calves",
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Target Focus",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Which muscle groups or target body areas should we prioritize in your training regimen?",
              style: TextStyle(color: textSecondary),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.4,
                ),
                itemCount: _muscles.length,
                itemBuilder: (context, index) {
                  final muscle = _muscles[index];
                  final isSelected = _targetAreas.contains(muscle);
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        if (isSelected) {
                          _targetAreas.remove(muscle);
                        } else {
                          _targetAreas.add(muscle);
                        }
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primary.withValues(alpha: 0.15)
                            : Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected
                              ? AppColors.secondary
                              : (isDark
                                    ? AppColors.glassBorderDark
                                    : AppColors.glassBorderLight),
                          width: isSelected ? 2 : 1,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.fitness_center_outlined,
                            color: isSelected
                                ? AppColors.secondary
                                : Colors.grey,
                            size: 28,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            muscle,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: isSelected ? Colors.white : textSecondary,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            CustomButton(
              text: "Continue",
              onPressed: () {
                final profile = ref.read(userProfileProvider);
                ref
                    .read(userProfileProvider.notifier)
                    .updateProfile(
                      profile.copyWith(targetBodyAreas: _targetAreas),
                    );
                context.push('/profile-setup-subscription');
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 14. Subscription Plan Screen
class SubscriptionPlanScreen extends ConsumerStatefulWidget {
  const SubscriptionPlanScreen({super.key});

  @override
  ConsumerState<SubscriptionPlanScreen> createState() =>
      _SubscriptionPlanScreenState();
}

class _SubscriptionPlanScreenState
    extends ConsumerState<SubscriptionPlanScreen> {
  String _selectedPlan = "Premium Pro";

  final List<Map<String, String>> _plans = [
    {
      "name": "Standard Access",
      "price": "\$9.99 / mo",
      "desc":
          "Includes standard workout plans, basic nutrition logs, and step tracking.",
    },
    {
      "name": "Premium Pro",
      "price": "\$19.99 / mo",
      "desc":
          "Recommended. Live AI Coaching chats, customized recovery algorithms, and HD libraries.",
    },
    {
      "name": "Elite Athlete",
      "price": "\$39.99 / mo",
      "desc":
          "Direct professional training integrations, advanced metric widgets, and premium challenges.",
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Unlock Elite Fitness",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Choose a subscription tier to activate your personalized AI training engine.",
              style: TextStyle(color: textSecondary),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: ListView.builder(
                itemCount: _plans.length,
                itemBuilder: (context, index) {
                  final plan = _plans[index];
                  final isSelected = _selectedPlan == plan["name"];
                  return SelectionCard(
                    title: "${plan["name"]} (${plan["price"]})",
                    description: plan["desc"]!,
                    isSelected: isSelected,
                    icon: Icons.workspace_premium,
                    onTap: () => setState(() => _selectedPlan = plan["name"]!),
                  );
                },
              ),
            ),
            CustomButton(
              text: "Start Premium Trial",
              onPressed: () {
                final profile = ref.read(userProfileProvider);
                ref
                    .read(userProfileProvider.notifier)
                    .updateProfile(
                      profile.copyWith(subscriptionPlan: _selectedPlan),
                    );
                // Configuration complete, jump to Main dashboard!
                context.go('/dashboard');
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
