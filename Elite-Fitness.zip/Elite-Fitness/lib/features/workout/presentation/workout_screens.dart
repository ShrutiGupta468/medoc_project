import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/custom_button.dart';
import '../../../core/providers/state_providers.dart';

// 16. Workout Categories Screen
class WorkoutCategoriesScreen extends ConsumerWidget {
  WorkoutCategoriesScreen({super.key});

  final List<Map<String, dynamic>> _categories = [
    {
      "name": "Strength",
      "icon": Icons.fitness_center,
      "image":
          "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "HIIT",
      "icon": Icons.bolt,
      "image":
          "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "Yoga",
      "icon": Icons.self_improvement,
      "image":
          "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "Cardio",
      "icon": Icons.directions_run,
      "image":
          "https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "CrossFit",
      "icon": Icons.sports_gymnastics,
      "image":
          "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "Calisthenics",
      "icon": Icons.accessibility_new,
      "image":
          "https://images.unsplash.com/photo-1549060263-7f97615ec1f4?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "Functional Training",
      "icon": Icons.layers,
      "image":
          "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&w=400&q=80",
    },
    {
      "name": "Stretching",
      "icon": Icons.airline_seat_flat_angled,
      "image":
          "https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=400&q=80",
    },
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final workouts = ref.watch(workoutsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Workout Categories"),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book),
            onPressed: () => context.push('/exercise-library'),
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.2,
        ),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final cat = _categories[index];

          // Filter workouts by category
          final filtered = workouts
              .where(
                (w) =>
                    w.category.toLowerCase() ==
                    cat["name"].toString().toLowerCase(),
              )
              .toList();

          return GestureDetector(
            onTap: () {
              // Simple screen display or display bottom sheet list of workouts
              showModalBottomSheet(
                context: context,
                backgroundColor: isDark ? AppColors.darkBg : AppColors.lightBg,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                builder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${cat["name"]} Routines",
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Outfit',
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (filtered.isEmpty)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 20.0),
                            child: Text(
                              "No routines found in this category right now. Ask AI Coach to build one!",
                            ),
                          )
                        else
                          ...filtered.map((w) {
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(
                                Icons.fitness_center,
                                color: AppColors.primary,
                              ),
                              title: Text(
                                w.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Text(
                                "${w.durationMinutes} min • ${w.difficulty}",
                              ),
                              trailing: const Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                                context.push('/workout-details/${w.id}');
                              },
                            );
                          }),
                      ],
                    ),
                  );
                },
              );
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: NetworkImage(cat["image"]),
                  fit: BoxFit.cover,
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withValues(alpha: 0.75),
                      Colors.black.withValues(alpha: 0.2),
                    ],
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                  ),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(cat["icon"], color: Colors.white, size: 24),
                    const SizedBox(height: 6),
                    Text(
                      cat["name"],
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        fontFamily: 'Outfit',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// 17. Workout Details Screen
class WorkoutDetailsScreen extends ConsumerWidget {
  final String workoutId;
  const WorkoutDetailsScreen({super.key, required this.workoutId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final workouts = ref.read(workoutsProvider);
    final workout = workouts.firstWhere(
      (w) => w.id == workoutId,
      orElse: () => workouts[0],
    );
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;
    final surfaceCardColor = isDark
        ? AppColors.darkSurfaceCard
        : AppColors.lightSurfaceCard;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            leading: CircleAvatar(
              backgroundColor: Colors.black38,
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => context.pop(),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title & Tag
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.primary),
                        ),
                        child: Text(
                          workout.category.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    workout.title,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Outfit',
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Primary Stats
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildDetailStat(
                        context,
                        Icons.timer_outlined,
                        "${workout.durationMinutes} Min",
                        "Duration",
                      ),
                      _buildDetailStat(
                        context,
                        Icons.local_fire_department_outlined,
                        "${workout.caloriesBurned} Kcal",
                        "Est. Burn",
                      ),
                      _buildDetailStat(
                        context,
                        Icons.fitness_center_outlined,
                        workout.difficulty,
                        "Difficulty",
                      ),
                    ],
                  ),
                  Divider(height: 40, color: surfaceCardColor),

                  // Description
                  const Text(
                    "Description",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    workout.description,
                    style: TextStyle(color: textSecondary, height: 1.5),
                  ),
                  const SizedBox(height: 24),

                  // Equipment Required
                  const Text(
                    "Equipment Required",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    children: workout.equipment
                        .map(
                          (eq) => Chip(
                            label: Text(eq),
                            backgroundColor: Theme.of(context).cardColor,
                            side: BorderSide.none,
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 24),

                  // Trainer Info
                  const Text(
                    "Trainer",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundImage: NetworkImage(workout.trainerAvatar),
                        radius: 24,
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            workout.trainerName,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Certified Strength Specialist",
                            style: TextStyle(
                              fontSize: 12,
                              color: textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),

                  // Exercise Breakdown list
                  const Text(
                    "Exercises Breakdown",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 12),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: workout.exercises.length,
                    itemBuilder: (context, index) {
                      final ex = workout.exercises[index];
                      return ListTile(
                        onTap: () => context.push('/exercise-details/${ex.id}'),
                        contentPadding: EdgeInsets.zero,
                        leading: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Theme.of(context).cardColor,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.play_circle_outline,
                            color: AppColors.secondary,
                          ),
                        ),
                        title: Text(
                          ex.name,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text("${ex.repsOrTime} • ${ex.targetMuscle}"),
                        trailing: const Icon(Icons.chevron_right, size: 18),
                      );
                    },
                  ),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomSheet: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          border: Border(top: BorderSide(color: surfaceCardColor, width: 0.5)),
        ),
        child: CustomButton(
          text: "Start Program",
          onPressed: () {
            context.push('/workout-player/${workout.id}');
          },
        ),
      ),
    );
  }

  Widget _buildDetailStat(
    BuildContext context,
    IconData icon,
    String value,
    String label,
  ) {
    return Column(
      children: [
        Icon(icon, color: AppColors.secondary, size: 24),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        ),
        Text(
          label,
          style: TextStyle(color: Theme.of(context).hintColor, fontSize: 11),
        ),
      ],
    );
  }
}

// 18. Workout Player Screen
class WorkoutPlayerScreen extends ConsumerStatefulWidget {
  final String workoutId;
  const WorkoutPlayerScreen({super.key, required this.workoutId});

  @override
  ConsumerState<WorkoutPlayerScreen> createState() =>
      _WorkoutPlayerScreenState();
}

class _WorkoutPlayerScreenState extends ConsumerState<WorkoutPlayerScreen> {
  Timer? _timer;
  int _secondsRemaining = 45;
  bool _isPlaying = true;
  int _currentExerciseIndex = 0;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_isPlaying) {
        setState(() {
          if (_secondsRemaining > 0) {
            _secondsRemaining--;
          } else {
            _nextExercise();
          }
        });
      }
    });
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  void _nextExercise() {
    final workouts = ref.read(workoutsProvider);
    final workout = workouts.firstWhere(
      (w) => w.id == widget.workoutId,
      orElse: () => workouts[0],
    );

    if (_currentExerciseIndex < workout.exercises.length - 1) {
      setState(() {
        _currentExerciseIndex++;
        _secondsRemaining = 45;
      });
    } else {
      _timer?.cancel();
      // Complete workout and log metrics!
      ref
          .read(dailyTrackerProvider.notifier)
          .completeWorkout(workout.caloriesBurned, workout.durationMinutes);

      // Congratulatory overlay dialog
      final isDark = Theme.of(context).brightness == Brightness.dark;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: isDark ? AppColors.darkSurface : AppColors.lightBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: const Center(
            child: Text(
              "WORKOUT COMPLETED! 🎉",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: AppColors.accent,
                fontFamily: 'Outfit',
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Incredible job! Defying limits is what Elite Fitness is all about.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isDark ? Colors.white70 : Colors.black87,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "+${workout.caloriesBurned} kcal burned",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              Text(
                "${workout.durationMinutes} active minutes logged",
                style: const TextStyle(color: AppColors.secondary),
              ),
            ],
          ),
          actions: [
            CustomButton(
              text: "Return to Dashboard",
              onPressed: () {
                Navigator.pop(context);
                context.go('/dashboard');
              },
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final workouts = ref.read(workoutsProvider);
    final workout = workouts.firstWhere(
      (w) => w.id == widget.workoutId,
      orElse: () => workouts[0],
    );
    final exercise = workout.exercises[_currentExerciseIndex];
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(workout.title),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => context.pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // Exercise Video Demonstration mockup
            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                image: const DecorationImage(
                  image: NetworkImage(
                    'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
                  ),
                  fit: BoxFit.cover,
                ),
                border: Border.all(
                  color: isDark
                      ? AppColors.glassBorderDark
                      : AppColors.glassBorderLight,
                ),
              ),
              child: Center(
                child: CircleAvatar(
                  backgroundColor: Colors.white.withValues(alpha: 0.2),
                  radius: 30,
                  child: const Icon(
                    Icons.play_arrow,
                    color: Colors.white,
                    size: 36,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Exercise Title
            Text(
              exercise.name,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: 'Outfit',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              "Target: ${exercise.targetMuscle} • ${exercise.repsOrTime}",
              style: const TextStyle(
                color: AppColors.secondary,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 36),

            // Exercise Timer Display
            Text(
              "00:${_secondsRemaining.toString().padLeft(2, '0')}",
              style: const TextStyle(
                fontSize: 64,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 36),

            // Voice assistant prompt mockup
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.volume_up, color: AppColors.accent),
                const SizedBox(width: 8),
                Text(
                  "Voice coach: 'Keep your chest tall.'",
                  style: TextStyle(
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.6)
                        : Colors.black54,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
            const Spacer(),

            // Timer controls
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: const Icon(Icons.replay, size: 32),
                  onPressed: () {
                    setState(() {
                      _secondsRemaining = 45;
                    });
                  },
                ),
                GestureDetector(
                  onTap: _togglePlayPause,
                  child: CircleAvatar(
                    radius: 36,
                    backgroundColor: AppColors.primary,
                    child: Icon(
                      _isPlaying ? Icons.pause : Icons.play_arrow,
                      size: 36,
                      color: Colors.white,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.skip_next, size: 32),
                  onPressed: _nextExercise,
                ),
              ],
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 19. Exercise Library Screen
class ExerciseLibraryScreen extends ConsumerStatefulWidget {
  const ExerciseLibraryScreen({super.key});

  @override
  ConsumerState<ExerciseLibraryScreen> createState() =>
      _ExerciseLibraryScreenState();
}

class _ExerciseLibraryScreenState extends ConsumerState<ExerciseLibraryScreen> {
  String _searchQuery = "";

  final List<ExerciseItem> _allExercises = [
    ExerciseItem(
      id: "e1",
      name: "Incline Barbell Bench Press",
      repsOrTime: "4 Sets x 8-10 Reps",
      targetMuscle: "Upper Chest",
      description:
          "Lie back on an incline bench at a 30-degree angle. Lower the bar to your upper chest and push upwards explosively.",
      tips: [
        "Keep your shoulder blades retracted.",
        "Bar should touch upper chest lightly.",
      ],
      mistakes: [
        "Bouncing the bar off your chest.",
        "Flaring elbow too wide (keep 45 deg).",
      ],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e2",
      name: "Standing Dumbbell Arnold Press",
      repsOrTime: "3 Sets x 12 Reps",
      targetMuscle: "Shoulders (Anterior/Lateral)",
      description:
          "Hold dumbbells in front of your shoulders, palms facing you. Rotate wrists as you push weights overhead.",
      tips: ["Avoid arching your lower back.", "Fully lock out at top."],
      mistakes: ["Using momentum/hip drive.", "Incorrect rotation timing."],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e3",
      name: "Dynamic Mountain Climbers",
      repsOrTime: "45 Seconds Active",
      targetMuscle: "Core / Abs",
      description:
          "From a push-up position, alternate driving knees towards your chest at a rapid pace while maintaining straight back.",
      tips: ["Keep hips level and low.", "Engage abs throughout."],
      mistakes: ["Hips raised too high.", "Bouncing legs up and down."],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e4",
      name: "Downward Facing Dog",
      repsOrTime: "60 Seconds Pose",
      targetMuscle: "Hamstrings & Shoulders",
      description:
          "Push hips up and back from your hands and toes, forming an inverted V shape with your body.",
      tips: [
        "Press palms firmly down.",
        "Engage quadriceps to relieve weight off arms.",
      ],
      mistakes: ["Rounding the spine.", "Bending elbows."],
      gifUrl: "",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = _allExercises
        .where(
          (ex) =>
              ex.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              ex.targetMuscle.toLowerCase().contains(
                _searchQuery.toLowerCase(),
              ),
        )
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Exercise Library")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                hintText: "Search exercises or muscle groups...",
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (val) {
                setState(() {
                  _searchQuery = val;
                });
              },
            ),
            const SizedBox(height: 20),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text("No exercises match your search query."),
                    )
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final ex = filtered[index];
                        final isDark =
                            Theme.of(context).brightness == Brightness.dark;
                        return Card(
                          color: isDark
                              ? AppColors.darkSurface.withValues(alpha: 0.8)
                              : AppColors.lightSurface.withValues(alpha: 0.8),
                          margin: const EdgeInsets.only(bottom: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: ListTile(
                            onTap: () =>
                                context.push('/exercise-details/${ex.id}'),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            title: Text(
                              ex.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              "${ex.targetMuscle} • ${ex.repsOrTime}",
                            ),
                            trailing: const Icon(
                              Icons.arrow_forward_ios,
                              size: 14,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// 20. Exercise Details Screen
class ExerciseDetailsScreen extends StatelessWidget {
  final String exerciseId;
  const ExerciseDetailsScreen({super.key, required this.exerciseId});

  // Fallback exercises
  static final List<ExerciseItem> _exercises = [
    ExerciseItem(
      id: "e1",
      name: "Incline Barbell Bench Press",
      repsOrTime: "4 Sets x 8-10 Reps",
      targetMuscle: "Upper Chest",
      description:
          "Lie back on an incline bench at a 30-degree angle. Lower the bar to your upper chest and push upwards explosively.",
      tips: [
        "Keep your shoulder blades retracted.",
        "Bar should touch upper chest lightly.",
      ],
      mistakes: [
        "Bouncing the bar off your chest.",
        "Flaring elbow too wide (keep 45 deg).",
      ],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e2",
      name: "Standing Dumbbell Arnold Press",
      repsOrTime: "3 Sets x 12 Reps",
      targetMuscle: "Shoulders (Anterior/Lateral)",
      description:
          "Hold dumbbells in front of your shoulders, palms facing you. Rotate wrists as you push weights overhead.",
      tips: ["Avoid arching your lower back.", "Fully lock out at top."],
      mistakes: ["Using momentum/hip drive.", "Incorrect rotation timing."],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e3",
      name: "Dynamic Mountain Climbers",
      repsOrTime: "45 Seconds Active",
      targetMuscle: "Core / Abs",
      description:
          "From a push-up position, alternate driving knees towards your chest at a rapid pace while maintaining straight back.",
      tips: ["Keep hips level and low.", "Engage abs throughout."],
      mistakes: ["Hips raised too high.", "Bouncing legs up and down."],
      gifUrl: "",
    ),
    ExerciseItem(
      id: "e4",
      name: "Downward Facing Dog",
      repsOrTime: "60 Seconds Pose",
      targetMuscle: "Hamstrings & Shoulders",
      description:
          "Push hips up and back from your hands and toes, forming an inverted V shape with your body.",
      tips: [
        "Press palms firmly down.",
        "Engage quadriceps to relieve weight off arms.",
      ],
      mistakes: ["Rounding the spine.", "Bending elbows."],
      gifUrl: "",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final ex = _exercises.firstWhere(
      (e) => e.id == exerciseId,
      orElse: () => _exercises[0],
    );
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textSecondary = isDark
        ? AppColors.darkTextSecondary
        : AppColors.lightTextSecondary;

    return Scaffold(
      appBar: AppBar(title: Text(ex.name)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // demonstration illustration placeholder
            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                image: const DecorationImage(
                  image: NetworkImage(
                    'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&w=600&q=80',
                  ),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Target Muscle group
            Row(
              children: [
                const Text(
                  "Target Muscle: ",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.secondary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    ex.targetMuscle,
                    style: const TextStyle(
                      color: AppColors.secondary,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Description
            const Text(
              "How to Perform",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              ex.description,
              style: TextStyle(color: textSecondary, height: 1.5),
            ),
            const SizedBox(height: 24),

            // Tips
            const Text(
              "Expert Tips",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: AppColors.accent,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            ...ex.tips.map(
              (tip) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "• ",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Expanded(
                      child: Text(tip, style: TextStyle(color: textSecondary)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Common Mistakes
            const Text(
              "Common Mistakes",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: AppColors.error,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 8),
            ...ex.mistakes.map(
              (mistake) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "• ",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Expanded(
                      child: Text(
                        mistake,
                        style: TextStyle(color: textSecondary),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
