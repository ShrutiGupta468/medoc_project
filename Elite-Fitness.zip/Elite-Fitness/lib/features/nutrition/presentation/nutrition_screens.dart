import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_gradients.dart';
import '../../../core/widgets/glass_card.dart';

import '../../../core/providers/state_providers.dart';

// Helper custom progress bar for Macros
class MacroProgressBar extends StatelessWidget {
  final String label;
  final int current;
  final int goal;
  final Color activeColor;

  const MacroProgressBar({
    super.key,
    required this.label,
    required this.current,
    required this.goal,
    required this.activeColor,
  });

  @override
  Widget build(BuildContext context) {
    final progress = (current / goal).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
            ),
            Text(
              "$current / ${goal}g",
              style: TextStyle(
                color: activeColor,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            height: 8,
            color: Colors.grey.withValues(alpha: 0.15),
            alignment: Alignment.centerLeft,
            child: FractionallySizedBox(
              widthFactor: progress,
              child: Container(color: activeColor),
            ),
          ),
        ),
      ],
    );
  }
}

// 22. Nutrition Dashboard
class NutritionDashboardScreen extends ConsumerWidget {
  const NutritionDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final meals = ref.watch(nutritionProvider);
    final nutritionNotifier = ref.read(nutritionProvider.notifier);
    final tracker = ref.watch(dailyTrackerProvider);

    final totalCals = nutritionNotifier.totalCalories;
    final totalProtein = nutritionNotifier.totalProtein;
    final totalCarbs = nutritionNotifier.totalCarbs;
    final totalFat = nutritionNotifier.totalFat;

    const calGoal = 2500;
    const proteinGoal = 160;
    const carbsGoal = 250;
    const fatGoal = 75;

    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Nutrition Dashboard"),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_month),
            onPressed: () => context.push('/meal-planner'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Calorie Card Progress Ring or visual
            GlassCard(
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Calorie Budget",
                          style: TextStyle(
                            color: isDark
                                ? AppColors.darkTextSecondary
                                : AppColors.lightTextSecondary,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "$totalCals kcal Logged",
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Outfit',
                          ),
                        ),
                        Text(
                          "of $calGoal kcal goal",
                          style: TextStyle(
                            color: Theme.of(context).hintColor,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.primary.withValues(alpha: 0.15),
                    ),
                    child: Center(
                      child: Text(
                        "${(calGoal - totalCals).clamp(0, calGoal)} \nleft",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Macros Row progress indicators
            const Text(
              "Macronutrient Targets",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 16),
            GlassCard(
              child: Column(
                children: [
                  MacroProgressBar(
                    label: "Protein",
                    current: totalProtein,
                    goal: proteinGoal,
                    activeColor: AppColors.accent,
                  ),
                  const SizedBox(height: 16),
                  MacroProgressBar(
                    label: "Carbs",
                    current: totalCarbs,
                    goal: carbsGoal,
                    activeColor: AppColors.secondary,
                  ),
                  const SizedBox(height: 16),
                  MacroProgressBar(
                    label: "Fats",
                    current: totalFat,
                    goal: fatGoal,
                    activeColor: AppColors.error,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Water Intake mini row tracker
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Hydration Tracker",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    fontFamily: 'Outfit',
                  ),
                ),
                TextButton(
                  onPressed: () => context.push('/water-intake'),
                  child: const Text(
                    "Open Tracker",
                    style: TextStyle(color: AppColors.primary),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => context.push('/water-intake'),
              child: GlassCard(
                child: Row(
                  children: [
                    const Icon(
                      Icons.water_drop,
                      color: AppColors.info,
                      size: 28,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${(tracker.waterIntakeMl / 1000).toStringAsFixed(1)} L Logged",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          Text(
                            "Daily goal is ${(tracker.waterGoalMl / 1000).toStringAsFixed(1)} L",
                            style: TextStyle(
                              color: Theme.of(context).hintColor,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.arrow_forward_ios,
                      size: 16,
                      color: Colors.grey,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Logged Meals title & log button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Today's Food Log",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    fontFamily: 'Outfit',
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () => context.push('/food-search'),
                  icon: const Icon(Icons.add, size: 14),
                  label: const Text("Log Food", style: TextStyle(fontSize: 12)),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            meals.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24.0),
                    child: Center(
                      child: Text(
                        "No meals logged today. Add some nutrient sources!",
                      ),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: meals.length,
                    itemBuilder: (context, index) {
                      final meal = meals[index];
                      return Dismissible(
                        key: Key(meal.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          decoration: BoxDecoration(
                            color: AppColors.error.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          child: const Icon(
                            Icons.delete,
                            color: AppColors.error,
                          ),
                        ),
                        onDismissed: (dir) {
                          ref
                              .read(nutritionProvider.notifier)
                              .removeMeal(meal.id);
                        },
                        child: Card(
                          color: isDark
                              ? AppColors.darkSurface
                              : AppColors.lightSurface,
                          margin: const EdgeInsets.only(bottom: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: ListTile(
                            title: Text(
                              meal.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              "${meal.mealType} • P: ${meal.protein}g C: ${meal.carbs}g F: ${meal.fat}g",
                            ),
                            trailing: Text(
                              "${meal.calories} kcal",
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// 23. Meal Planner Screen
class MealPlannerScreen extends StatelessWidget {
  const MealPlannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final List<Map<String, String>> suggestions = [
      {
        "name": "Greek Yogurt Bowl",
        "type": "Breakfast",
        "macro": "280 kcal • P: 24g",
      },
      {
        "name": "Salmon Quinoa bowl",
        "type": "Lunch",
        "macro": "620 kcal • P: 45g",
      },
      {
        "name": "Stir-fried Tofu & Rice",
        "type": "Dinner",
        "macro": "480 kcal • P: 18g",
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("AI Meal Planner")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // AI Box suggestion banner
            GlassCard(
              bgColor: AppColors.primary.withValues(alpha: 0.1),
              child: Row(
                children: [
                  const Icon(
                    Icons.lightbulb,
                    color: AppColors.secondary,
                    size: 28,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "AI Coach Advice",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.secondary,
                          ),
                        ),
                        Text(
                          "For optimal muscle repair post-workout, consume a meal high in leucine (eg. salmon or whey) within 2 hours.",
                          style: TextStyle(
                            fontSize: 12,
                            color: isDark ? Colors.white70 : Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            const Text(
              "AI Suggested Meals",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 12),

            ...suggestions.map((s) {
              return Card(
                color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ListTile(
                  title: Text(
                    s["name"]!,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text("${s["type"]} • ${s["macro"]}"),
                  trailing: ElevatedButton(
                    onPressed: () {
                      context.push('/food-search');
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text("Log", style: TextStyle(fontSize: 12)),
                  ),
                ),
              );
            }),
            const SizedBox(height: 24),

            const Text(
              "Macro Allocation",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: 'Outfit',
              ),
            ),
            const SizedBox(height: 12),
            GlassCard(
              child: Column(
                children: [
                  _buildMealSlot(
                    "Breakfast",
                    "30% Calories (750 kcal)",
                    isDark,
                  ),
                  Divider(
                    height: 24,
                    color: isDark
                        ? AppColors.darkSurfaceCard
                        : AppColors.lightSurfaceCard,
                  ),
                  _buildMealSlot("Lunch", "40% Calories (1000 kcal)", isDark),
                  Divider(
                    height: 24,
                    color: isDark
                        ? AppColors.darkSurfaceCard
                        : AppColors.lightSurfaceCard,
                  ),
                  _buildMealSlot("Dinner", "30% Calories (750 kcal)", isDark),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMealSlot(String name, String allocation, bool isDark) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(
              allocation,
              style: TextStyle(
                color: isDark
                    ? AppColors.darkTextSecondary
                    : AppColors.lightTextSecondary,
                fontSize: 12,
              ),
            ),
          ],
        ),
        const Icon(Icons.circle_outlined, color: AppColors.primary, size: 20),
      ],
    );
  }
}

// 24. Food Search Screen
class FoodSearchScreen extends ConsumerStatefulWidget {
  const FoodSearchScreen({super.key});

  @override
  ConsumerState<FoodSearchScreen> createState() => _FoodSearchScreenState();
}

class _FoodSearchScreenState extends ConsumerState<FoodSearchScreen> {
  String _query = "";

  final List<MealItem> _foodDatabase = [
    MealItem(
      id: "db1",
      name: "Grilled Salmon Fillet (200g)",
      mealType: "Lunch",
      calories: 380,
      protein: 40,
      carbs: 0,
      fat: 22,
    ),
    MealItem(
      id: "db2",
      name: "Steamed Jasmine Rice (150g)",
      mealType: "Lunch",
      calories: 200,
      protein: 4,
      carbs: 44,
      fat: 0,
    ),
    MealItem(
      id: "db3",
      name: "Grass-Fed Whey Protein Shake",
      mealType: "Snack",
      calories: 150,
      protein: 30,
      carbs: 3,
      fat: 2,
    ),
    MealItem(
      id: "db4",
      name: "Boiled Eggs (Large, 2 qty)",
      mealType: "Breakfast",
      calories: 140,
      protein: 12,
      carbs: 1,
      fat: 10,
    ),
    MealItem(
      id: "db5",
      name: "Avocado Toast (Whole Grain)",
      mealType: "Breakfast",
      calories: 310,
      protein: 8,
      carbs: 26,
      fat: 19,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final filtered = _foodDatabase
        .where((food) => food.name.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Search Foods")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                hintText: "Search chicken, salmon, oats...",
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (val) {
                setState(() {
                  _query = val;
                });
              },
            ),
            const SizedBox(height: 20),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text(
                        "No items found. Tap custom log to add manually.",
                      ),
                    )
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final food = filtered[index];
                        return Card(
                          color: isDark
                              ? AppColors.darkSurface
                              : AppColors.lightSurface,
                          margin: const EdgeInsets.only(bottom: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: ListTile(
                            title: Text(
                              food.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              "P: ${food.protein}g C: ${food.carbs}g F: ${food.fat}g",
                            ),
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "${food.calories} kcal",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.secondary,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                GestureDetector(
                                  onTap: () {
                                    ref
                                        .read(nutritionProvider.notifier)
                                        .addMeal(food);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text("Logged ${food.name}!"),
                                        duration: const Duration(seconds: 1),
                                      ),
                                    );
                                  },
                                  child: const Text(
                                    "LOG +",
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// 25. Water Intake Tracker
class WaterIntakeTrackerScreen extends ConsumerWidget {
  const WaterIntakeTrackerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tracker = ref.watch(dailyTrackerProvider);
    final waterProgress = (tracker.waterIntakeMl / tracker.waterGoalMl).clamp(
      0.0,
      1.2,
    );
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text("Hydration Tracker")),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Liquid visualization container
              Container(
                width: 200,
                height: 300,
                decoration: BoxDecoration(
                  color: isDark
                      ? AppColors.darkSurface
                      : AppColors.lightSurface,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: AppColors.glassBorderDark,
                    width: 2,
                  ),
                ),
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    // Dynamic liquid wave simulation container
                    FractionallySizedBox(
                      heightFactor: (waterProgress).clamp(0.0, 1.0),
                      widthFactor: 1.0,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: AppGradients.waterIntake,
                          borderRadius: const BorderRadius.only(
                            bottomLeft: Radius.circular(28),
                            bottomRight: Radius.circular(28),
                          ),
                        ),
                      ),
                    ),
                    // Centered stats Overlay text
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "${(tracker.waterIntakeMl / 1000).toStringAsFixed(1)} L",
                            style: const TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Outfit',
                            ),
                          ),
                          Text(
                            "of ${(tracker.waterGoalMl / 1000).toStringAsFixed(1)} L",
                            style: TextStyle(
                              color: Theme.of(context).hintColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),

              const Text(
                "Quick Log Water",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(height: 16),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildWaterCupButton(ref, "250ml", 250),
                  const SizedBox(width: 12),
                  _buildWaterCupButton(ref, "500ml", 500),
                  const SizedBox(width: 12),
                  _buildWaterCupButton(ref, "1.0L", 1000),
                ],
              ),
              const SizedBox(height: 32),

              TextButton(
                onPressed: () {
                  ref.read(dailyTrackerProvider.notifier).resetWater();
                },
                child: const Text(
                  "Reset Tracker Today",
                  style: TextStyle(color: AppColors.error),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWaterCupButton(WidgetRef ref, String label, double amountMl) {
    return ElevatedButton.icon(
      icon: const Icon(Icons.water_drop, size: 14),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.info.withValues(alpha: 0.15),
        foregroundColor: AppColors.info,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      onPressed: () {
        ref.read(dailyTrackerProvider.notifier).addWater(amountMl);
      },
    );
  }
}
