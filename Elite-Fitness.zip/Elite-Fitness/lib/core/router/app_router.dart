import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'dart:ui';

// Import Screens
import '../../features/auth/presentation/auth_screens.dart';
import '../../features/profile_setup/presentation/profile_setup_screens.dart';
import '../../features/dashboard/presentation/home_dashboard_screen.dart';
import '../../features/workout/presentation/workout_screens.dart';
import '../../features/ai_coach/presentation/ai_coach_screen.dart';
import '../../features/nutrition/presentation/nutrition_screens.dart';
import '../../features/progress/presentation/progress_screens.dart';
import '../../features/community/presentation/community_screens.dart';
import '../../features/settings/presentation/settings_screens.dart';
import '../theme/app_colors.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'root',
);
final GlobalKey<NavigatorState> _shellNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'shell',
);

class AppRouter {
  static final router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    routes: [
      // Auth Flow
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding1',
        builder: (context, state) => const OnboardingOneScreen(),
      ),
      GoRoute(
        path: '/onboarding2',
        builder: (context, state) => const OnboardingTwoScreen(),
      ),
      GoRoute(
        path: '/onboarding3',
        builder: (context, state) => const OnboardingThreeScreen(),
      ),
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(
        path: '/signup',
        builder: (context, state) => const SignUpScreen(),
      ),
      GoRoute(
        path: '/forgot-password',
        builder: (context, state) => ForgotPasswordScreen(),
      ),
      GoRoute(
        path: '/otp-verification',
        builder: (context, state) => const OtpVerificationScreen(),
      ),

      // Profile Setup Flow
      GoRoute(
        path: '/profile-setup-personal',
        builder: (context, state) => const PersonalInfoScreen(),
      ),
      GoRoute(
        path: '/profile-setup-goal',
        builder: (context, state) => const FitnessGoalScreen(),
      ),
      GoRoute(
        path: '/profile-setup-activity',
        builder: (context, state) => const ActivityLevelScreen(),
      ),
      GoRoute(
        path: '/profile-setup-health',
        builder: (context, state) => const HealthConditionsScreen(),
      ),
      GoRoute(
        path: '/profile-setup-target',
        builder: (context, state) => const TargetBodyAreasScreen(),
      ),
      GoRoute(
        path: '/profile-setup-subscription',
        builder: (context, state) => const SubscriptionPlanScreen(),
      ),

      // Main App Shell (Tabs Navigation)
      ShellRoute(
        navigatorKey: _shellNavigatorKey,
        builder: (context, state, child) {
          return MainShellLayout(child: child);
        },
        routes: [
          GoRoute(
            path: '/dashboard',
            builder: (context, state) => const HomeDashboardScreen(),
          ),
          GoRoute(
            path: '/workout-categories',
            builder: (context, state) => WorkoutCategoriesScreen(),
          ),
          GoRoute(
            path: '/ai-coach',
            builder: (context, state) => const AICoachScreen(),
          ),
          GoRoute(
            path: '/nutrition-dashboard',
            builder: (context, state) => const NutritionDashboardScreen(),
          ),
          GoRoute(
            path: '/profile-settings',
            builder: (context, state) => const SettingsScreen(),
          ),
        ],
      ),

      // Deep linked sub-screens outside tab bar shell for full screen focus
      GoRoute(
        path: '/workout-details/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            WorkoutDetailsScreen(workoutId: state.pathParameters['id'] ?? 'w1'),
      ),
      GoRoute(
        path: '/workout-player/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) =>
            WorkoutPlayerScreen(workoutId: state.pathParameters['id'] ?? 'w1'),
      ),
      GoRoute(
        path: '/exercise-library',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ExerciseLibraryScreen(),
      ),
      GoRoute(
        path: '/exercise-details/:id',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => ExerciseDetailsScreen(
          exerciseId: state.pathParameters['id'] ?? 'e1',
        ),
      ),
      GoRoute(
        path: '/meal-planner',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const MealPlannerScreen(),
      ),
      GoRoute(
        path: '/food-search',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const FoodSearchScreen(),
      ),
      GoRoute(
        path: '/water-intake',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const WaterIntakeTrackerScreen(),
      ),
      GoRoute(
        path: '/progress-dashboard',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ProgressDashboardScreen(),
      ),
      GoRoute(
        path: '/statistics',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const StatisticsScreen(),
      ),
      GoRoute(
        path: '/community-feed',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const CommunityFeedScreen(),
      ),
      GoRoute(
        path: '/edit-profile',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const EditProfileScreen(),
      ),
    ],
  );
}

// Custom Glassmorphic Shell layout with navigation bar
class MainShellLayout extends StatefulWidget {
  final Widget child;
  const MainShellLayout({super.key, required this.child});

  @override
  State<MainShellLayout> createState() => _MainShellLayoutState();
}

class _MainShellLayoutState extends State<MainShellLayout> {
  int _getCurrentIndex(BuildContext context) {
    final String location = GoRouterState.of(context).uri.toString();
    if (location == '/dashboard') return 0;
    if (location == '/workout-categories') return 1;
    if (location == '/ai-coach') return 2;
    if (location == '/nutrition-dashboard') return 3;
    if (location == '/profile-settings') return 4;
    return 0;
  }

  void _onTabTapped(BuildContext context, int index) {
    switch (index) {
      case 0:
        context.go('/dashboard');
        break;
      case 1:
        context.go('/workout-categories');
        break;
      case 2:
        context.go('/ai-coach');
        break;
      case 3:
        context.go('/nutrition-dashboard');
        break;
      case 4:
        context.go('/profile-settings');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final int selectedIndex = _getCurrentIndex(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBody: true,
      body: widget.child,
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.25),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18.0, sigmaY: 18.0),
            child: BottomNavigationBar(
              currentIndex: selectedIndex,
              onTap: (index) => _onTabTapped(context, index),
              backgroundColor: isDark
                  ? AppColors.darkSurface.withValues(alpha: 0.6)
                  : AppColors.lightSurface.withValues(alpha: 0.7),
              selectedItemColor: AppColors.primary,
              unselectedItemColor: isDark
                  ? AppColors.darkTextSecondary
                  : AppColors.lightTextSecondary,
              showSelectedLabels: true,
              showUnselectedLabels: false,
              selectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
              elevation: 0,
              type: BottomNavigationBarType.fixed,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home_filled),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.fitness_center),
                  label: 'Workout',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.bolt),
                  label: 'AI Coach',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.local_dining_outlined),
                  label: 'Nutrition',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person_outline),
                  label: 'Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
