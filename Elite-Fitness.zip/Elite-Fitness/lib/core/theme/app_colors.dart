import 'package:flutter/material.dart';

class AppColors {
  // Brand Colors
  static const Color primary = Color(0xFF4F46E5); // Electric Indigo
  static const Color secondary = Color(0xFF06B6D4); // Cyan
  static const Color accent = Color(0xFF22C55E); // Fitness Green

  // Dark Theme
  static const Color darkBg = Color(0xFF0F172A);
  static const Color darkSurface = Color(0xFF1E293B);
  static const Color darkSurfaceCard = Color(0xFF334155);
  static const Color darkTextPrimary = Color(0xFFF8FAFC);
  static const Color darkTextSecondary = Color(0xFF94A3B8);

  // Light Theme
  static const Color lightBg = Color(0xFFFFFFFF);
  static const Color lightSurface = Color(0xFFF8FAFC);
  static const Color lightSurfaceCard = Color(0xFFE2E8F0);
  static const Color lightTextPrimary = Color(0xFF0F172A);
  static const Color lightTextSecondary = Color(0xFF64748B);

  // Glassmorphic border & overlay colors
  static Color glassBorderDark = const Color(
    0xFFFFFFFF,
  ).withValues(alpha: 0.08);
  static Color glassBgDark = const Color(0xFF1E293B).withValues(alpha: 0.4);
  static Color glassBorderLight = const Color(
    0xFF000000,
  ).withValues(alpha: 0.06);
  static Color glassBgLight = const Color(0xFFFFFFFF).withValues(alpha: 0.6);

  // State colors
  static const Color error = Color(0xFFEF4444);
  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF59E0B);
  static const Color info = Color(0xFF3B82F6);
}
