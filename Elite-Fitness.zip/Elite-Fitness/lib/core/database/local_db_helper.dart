import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

class LocalDBHelper {
  static final LocalDBHelper _instance = LocalDBHelper._internal();
  static Database? _database;

  factory LocalDBHelper() => _instance;

  LocalDBHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDb();
    return _database!;
  }

  Future<Database> _initDb() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, 'elite_fitness.db');

    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    // Create Users table
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER,
        gender TEXT,
        height REAL,
        weight REAL,
        goal TEXT,
        activityLevel TEXT,
        subscriptionPlan TEXT,
        streakDays INTEGER
      )
    ''');

    // Create DailyTracker table
    await db.execute('''
      CREATE TABLE daily_tracker (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        stepsWalked INTEGER,
        stepsGoal INTEGER,
        caloriesBurned INTEGER,
        caloriesGoal INTEGER,
        waterIntakeMl REAL,
        waterGoalMl REAL,
        activeMinutes INTEGER,
        activeMinutesGoal INTEGER
      )
    ''');

    // Insert Default User
    await db.insert('users', {
      'name': 'Alex Mercer',
      'age': 26,
      'gender': 'Male',
      'height': 182.0,
      'weight': 78.5,
      'goal': 'Muscle Gain',
      'activityLevel': 'Moderately Active',
      'subscriptionPlan': 'Premium Pro',
      'streakDays': 5,
    });

    final today = DateTime.now().toIso8601String().split('T')[0];

    // Insert Default Tracker
    await db.insert('daily_tracker', {
      'date': today,
      'stepsWalked': 8432,
      'stepsGoal': 10000,
      'caloriesBurned': 420,
      'caloriesGoal': 750,
      'waterIntakeMl': 1250.0,
      'waterGoalMl': 3000.0,
      'activeMinutes': 35,
      'activeMinutesGoal': 60,
    });
  }

  // --- User Profile Operations ---
  Future<Map<String, dynamic>?> getUser() async {
    final db = await database;
    final res = await db.query('users', limit: 1);
    if (res.isNotEmpty) {
      return res.first;
    }
    return null;
  }

  Future<int> updateUser(Map<String, dynamic> user) async {
    final db = await database;
    return await db.update(
      'users',
      user,
      where: 'id = ?',
      whereArgs: [user['id'] ?? 1],
    );
  }

  // --- Daily Tracker Operations ---
  Future<Map<String, dynamic>?> getDailyTracker() async {
    final db = await database;
    final today = DateTime.now().toIso8601String().split('T')[0];

    final res = await db.query(
      'daily_tracker',
      where: 'date = ?',
      whereArgs: [today],
      limit: 1,
    );

    if (res.isNotEmpty) {
      return res.first;
    } else {
      // Create a new record for today based on previous goals if needed, or default
      final defaultTracker = {
        'date': today,
        'stepsWalked': 0,
        'stepsGoal': 10000,
        'caloriesBurned': 0,
        'caloriesGoal': 750,
        'waterIntakeMl': 0.0,
        'waterGoalMl': 3000.0,
        'activeMinutes': 0,
        'activeMinutesGoal': 60,
      };
      await db.insert('daily_tracker', defaultTracker);
      return defaultTracker;
    }
  }

  Future<int> updateDailyTracker(Map<String, dynamic> tracker) async {
    final db = await database;
    final today = DateTime.now().toIso8601String().split('T')[0];
    return await db.update(
      'daily_tracker',
      tracker,
      where: 'date = ?',
      whereArgs: [today],
    );
  }
}
