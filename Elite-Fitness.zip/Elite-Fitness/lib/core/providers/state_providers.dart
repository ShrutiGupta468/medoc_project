import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../database/local_db_helper.dart';

// --- MODELS ---

class UserProfile {
  final String name;
  final int age;
  final String gender;
  final double height; // cm
  final double weight; // kg
  final String goal;
  final String activityLevel;
  final List<String> healthConditions;
  final List<String> targetBodyAreas;
  final String subscriptionPlan;
  final int streakDays;

  UserProfile({
    required this.name,
    required this.age,
    required this.gender,
    required this.height,
    required this.weight,
    required this.goal,
    required this.activityLevel,
    required this.healthConditions,
    required this.targetBodyAreas,
    required this.subscriptionPlan,
    this.streakDays = 5,
  });

  factory UserProfile.fromMap(Map<String, dynamic> map) {
    return UserProfile(
      name: map['name'] ?? 'Alex Mercer',
      age: map['age'] ?? 26,
      gender: map['gender'] ?? 'Male',
      height: map['height'] ?? 182.0,
      weight: map['weight'] ?? 78.5,
      goal: map['goal'] ?? 'Muscle Gain',
      activityLevel: map['activityLevel'] ?? 'Moderately Active',
      healthConditions: [], // We omitted this in db for simplicity
      targetBodyAreas: ["Chest", "Shoulders", "Abs"], // We omitted this in db
      subscriptionPlan: map['subscriptionPlan'] ?? 'Premium Pro',
      streakDays: map['streakDays'] ?? 5,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'age': age,
      'gender': gender,
      'height': height,
      'weight': weight,
      'goal': goal,
      'activityLevel': activityLevel,
      'subscriptionPlan': subscriptionPlan,
      'streakDays': streakDays,
    };
  }

  UserProfile copyWith({
    String? name,
    int? age,
    String? gender,
    double? height,
    double? weight,
    String? goal,
    String? activityLevel,
    List<String>? healthConditions,
    List<String>? targetBodyAreas,
    String? subscriptionPlan,
    int? streakDays,
  }) {
    return UserProfile(
      name: name ?? this.name,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      goal: goal ?? this.goal,
      activityLevel: activityLevel ?? this.activityLevel,
      healthConditions: healthConditions ?? this.healthConditions,
      targetBodyAreas: targetBodyAreas ?? this.targetBodyAreas,
      subscriptionPlan: subscriptionPlan ?? this.subscriptionPlan,
      streakDays: streakDays ?? this.streakDays,
    );
  }
}

class DailyTracker {
  final int stepsWalked;
  final int stepsGoal;
  final int caloriesBurned;
  final int caloriesGoal;
  final double waterIntakeMl;
  final double waterGoalMl;
  final int activeMinutes;
  final int activeMinutesGoal;

  DailyTracker({
    required this.stepsWalked,
    required this.stepsGoal,
    required this.caloriesBurned,
    required this.caloriesGoal,
    required this.waterIntakeMl,
    required this.waterGoalMl,
    required this.activeMinutes,
    required this.activeMinutesGoal,
  });

  factory DailyTracker.fromMap(Map<String, dynamic> map) {
    return DailyTracker(
      stepsWalked: map['stepsWalked'] ?? 0,
      stepsGoal: map['stepsGoal'] ?? 10000,
      caloriesBurned: map['caloriesBurned'] ?? 0,
      caloriesGoal: map['caloriesGoal'] ?? 750,
      waterIntakeMl: map['waterIntakeMl'] ?? 0.0,
      waterGoalMl: map['waterGoalMl'] ?? 3000.0,
      activeMinutes: map['activeMinutes'] ?? 0,
      activeMinutesGoal: map['activeMinutesGoal'] ?? 60,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'stepsWalked': stepsWalked,
      'stepsGoal': stepsGoal,
      'caloriesBurned': caloriesBurned,
      'caloriesGoal': caloriesGoal,
      'waterIntakeMl': waterIntakeMl,
      'waterGoalMl': waterGoalMl,
      'activeMinutes': activeMinutes,
      'activeMinutesGoal': activeMinutesGoal,
    };
  }

  DailyTracker copyWith({
    int? stepsWalked,
    int? stepsGoal,
    int? caloriesBurned,
    int? caloriesGoal,
    double? waterIntakeMl,
    double? waterGoalMl,
    int? activeMinutes,
    int? activeMinutesGoal,
  }) {
    return DailyTracker(
      stepsWalked: stepsWalked ?? this.stepsWalked,
      stepsGoal: stepsGoal ?? this.stepsGoal,
      caloriesBurned: caloriesBurned ?? this.caloriesBurned,
      caloriesGoal: caloriesGoal ?? this.caloriesGoal,
      waterIntakeMl: waterIntakeMl ?? this.waterIntakeMl,
      waterGoalMl: waterGoalMl ?? this.waterGoalMl,
      activeMinutes: activeMinutes ?? this.activeMinutes,
      activeMinutesGoal: activeMinutesGoal ?? this.activeMinutesGoal,
    );
  }
}

class WorkoutItem {
  final String id;
  final String title;
  final String category;
  final String difficulty;
  final int durationMinutes;
  final int caloriesBurned;
  final String trainerName;
  final String trainerAvatar;
  final List<String> equipment;
  final String description;
  final List<ExerciseItem> exercises;

  WorkoutItem({
    required this.id,
    required this.title,
    required this.category,
    required this.difficulty,
    required this.durationMinutes,
    required this.caloriesBurned,
    required this.trainerName,
    required this.trainerAvatar,
    required this.equipment,
    required this.description,
    required this.exercises,
  });
}

class ExerciseItem {
  final String id;
  final String name;
  final String repsOrTime;
  final String targetMuscle;
  final String description;
  final List<String> tips;
  final List<String> mistakes;
  final String gifUrl;

  ExerciseItem({
    required this.id,
    required this.name,
    required this.repsOrTime,
    required this.targetMuscle,
    required this.description,
    required this.tips,
    required this.mistakes,
    required this.gifUrl,
  });
}

class ChatMessage {
  final String id;
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class MealItem {
  final String id;
  final String name;
  final String mealType; // Breakfast, Lunch, Dinner, Snack
  final int calories;
  final int protein;
  final int carbs;
  final int fat;

  MealItem({
    required this.id,
    required this.name,
    required this.mealType,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
  });
}

class CommunityPost {
  final String id;
  final String userName;
  final String userAvatar;
  final String timeAgo;
  final String content;
  final String? imagePath;
  int likes;
  int commentsCount;
  bool isLiked;

  CommunityPost({
    required this.id,
    required this.userName,
    required this.userAvatar,
    required this.timeAgo,
    required this.content,
    this.imagePath,
    required this.likes,
    required this.commentsCount,
    this.isLiked = false,
  });
}

// --- STATE NOTIFIERS ---

class UserProfileNotifier extends StateNotifier<UserProfile> {
  UserProfileNotifier()
    : super(
        UserProfile(
          name: "Alex Mercer",
          age: 26,
          gender: "Male",
          height: 182,
          weight: 78.5,
          goal: "Muscle Gain",
          activityLevel: "Moderately Active",
          healthConditions: [],
          targetBodyAreas: ["Chest", "Shoulders", "Abs"],
          subscriptionPlan: "Premium Pro",
        ),
      ) {
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final db = LocalDBHelper();
    final data = await db.getUser();
    if (data != null) {
      state = UserProfile.fromMap(data);
    }
  }

  Future<void> updateProfile(UserProfile newProfile) async {
    state = newProfile;
    final db = LocalDBHelper();
    await db.updateUser(newProfile.toMap());
  }
}

class DailyTrackerNotifier extends StateNotifier<DailyTracker> {
  DailyTrackerNotifier()
    : super(
        DailyTracker(
          stepsWalked: 8432,
          stepsGoal: 10000,
          caloriesBurned: 420,
          caloriesGoal: 750,
          waterIntakeMl: 1250,
          waterGoalMl: 3000,
          activeMinutes: 35,
          activeMinutesGoal: 60,
        ),
      ) {
    _loadTracker();
  }

  Future<void> _loadTracker() async {
    final db = LocalDBHelper();
    final data = await db.getDailyTracker();
    if (data != null) {
      state = DailyTracker.fromMap(data);
    }
  }

  Future<void> addWater(double amountMl) async {
    state = state.copyWith(waterIntakeMl: state.waterIntakeMl + amountMl);
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }

  Future<void> resetWater() async {
    state = state.copyWith(waterIntakeMl: 0);
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }

  Future<void> addSteps(int steps) async {
    state = state.copyWith(stepsWalked: state.stepsWalked + steps);
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }

  Future<void> addCalories(int calories) async {
    state = state.copyWith(caloriesBurned: state.caloriesBurned + calories);
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }

  Future<void> addActiveMinutes(int minutes) async {
    state = state.copyWith(activeMinutes: state.activeMinutes + minutes);
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }

  Future<void> completeWorkout(int calories, int minutes) async {
    state = state.copyWith(
      caloriesBurned: state.caloriesBurned + calories,
      activeMinutes: state.activeMinutes + minutes,
    );
    final db = LocalDBHelper();
    await db.updateDailyTracker(state.toMap());
  }
}

class WorkoutsNotifier extends StateNotifier<List<WorkoutItem>> {
  WorkoutsNotifier() : super(_initialWorkouts);

  static final List<WorkoutItem> _initialWorkouts = [
    WorkoutItem(
      id: "w1",
      title: "Hypertrophy Push Protocol",
      category: "Strength",
      difficulty: "Advanced",
      durationMinutes: 45,
      caloriesBurned: 350,
      trainerName: "Coach Marcus",
      trainerAvatar:
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
      equipment: ["Dumbbells", "Barbell", "Bench"],
      description:
          "A comprehensive push day focusing on building vertical and horizontal pressing power, targeting chest, shoulders, and triceps.",
      exercises: [
        ExerciseItem(
          id: "e1",
          name: "Incline Barbell Bench Press",
          repsOrTime: "4 Sets x 8-10 Reps",
          targetMuscle: "Upper Chest",
          description:
              "Lie back on an incline bench at a 30-degree angle. Lower the bar to your upper chest and push upwards explosively.",
          tips: [
            "Keep your shoulder blades retracted.",
            "Bar should touch upper chest lightly.",
          ],
          mistakes: [
            "Bouncing the bar off your chest.",
            "Flaring elbow too wide (keep 45 deg).",
          ],
          gifUrl: "",
        ),
        ExerciseItem(
          id: "e2",
          name: "Standing Dumbbell Arnold Press",
          repsOrTime: "3 Sets x 12 Reps",
          targetMuscle: "Shoulders (Anterior/Lateral)",
          description:
              "Hold dumbbells in front of your shoulders, palms facing you. Rotate wrists as you push weights overhead.",
          tips: ["Avoid arching your lower back.", "Fully lock out at top."],
          mistakes: ["Using momentum/hip drive.", "Incorrect rotation timing."],
          gifUrl: "",
        ),
      ],
    ),
    WorkoutItem(
      id: "w2",
      title: "Core Incinerator HIIT",
      category: "HIIT",
      difficulty: "Intermediate",
      durationMinutes: 20,
      caloriesBurned: 240,
      trainerName: "Sophia Carter",
      trainerAvatar:
          "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80",
      equipment: ["No Equipment", "Mat"],
      description:
          "High intensity cardiovascular and core routine designed to burn fat and build functional trunk stability.",
      exercises: [
        ExerciseItem(
          id: "e3",
          name: "Dynamic Mountain Climbers",
          repsOrTime: "45 Seconds Active",
          targetMuscle: "Core / Abs",
          description:
              "From a push-up position, alternate driving knees towards your chest at a rapid pace while maintaining straight back.",
          tips: ["Keep hips level and low.", "Engage abs throughout."],
          mistakes: ["Hips raised too high.", "Bouncing legs up and down."],
          gifUrl: "",
        ),
      ],
    ),
    WorkoutItem(
      id: "w3",
      title: "Vinyasa Flow Restoration",
      category: "Yoga",
      difficulty: "Beginner",
      durationMinutes: 30,
      caloriesBurned: 120,
      trainerName: "Yogi Amanda",
      trainerAvatar:
          "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80",
      equipment: ["Yoga Mat"],
      description:
          "Slow restorative flow to enhance joint range of motion, clear lactic acid, and calm down the nervous system.",
      exercises: [
        ExerciseItem(
          id: "e4",
          name: "Downward Facing Dog",
          repsOrTime: "60 Seconds Pose",
          targetMuscle: "Hamstrings & Shoulders",
          description:
              "Push hips up and back from your hands and toes, forming an inverted V shape with your body.",
          tips: [
            "Press palms firmly down.",
            "Engage quadriceps to relieve weight off arms.",
          ],
          mistakes: ["Rounding the spine.", "Bending elbows."],
          gifUrl: "",
        ),
      ],
    ),
  ];
}

class ChatNotifier extends StateNotifier<List<ChatMessage>> {
  ChatNotifier()
    : super([
        ChatMessage(
          id: "1",
          text:
              "Hello Alex! I am your Elite Fitness Coach. I can help analyze your goals and suggest personalized meals or routines. What are we focusing on today?",
          isUser: false,
          timestamp: DateTime.now().subtract(const Duration(minutes: 10)),
        ),
      ]);

  void sendMessage(String text) {
    final userMsg = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      text: text,
      isUser: true,
      timestamp: DateTime.now(),
    );

    state = [...state, userMsg];

    // Generate intelligent AI response based on keywords
    Future.delayed(const Duration(seconds: 1), () {
      String replyText =
          "That sounds like a great plan! To optimize your performance, make sure you maintain a slight caloric surplus, get 150g of protein, and hit your hydration targets.";

      final query = text.toLowerCase();
      if (query.contains("workout") ||
          query.contains("exercise") ||
          query.contains("train")) {
        replyText =
            "For your Muscle Gain goal, I recommend a heavy compound-lift routing focusing on progressive overload. I've highlighted the 'Hypertrophy Push Protocol' for you. Ready to get started?";
      } else if (query.contains("diet") ||
          query.contains("meal") ||
          query.contains("eat") ||
          query.contains("protein")) {
        replyText =
            "Nutrition is key. Since you're targeting Muscle Gain, let's aim for a high protein meal: Grilled Salmon (250g) with Quinoa and Roasted Asparagus (approx. 620 kcal, 45g Protein).";
      } else if (query.contains("water") || query.contains("drink")) {
        replyText =
            "Hydration is essential for muscle recovery. Try to drink at least 3.0 Liters today. You can log water directly on your Nutrition Dashboard.";
      }

      final coachMsg = ChatMessage(
        id: (DateTime.now().millisecondsSinceEpoch + 1).toString(),
        text: replyText,
        isUser: false,
        timestamp: DateTime.now(),
      );

      state = [...state, coachMsg];
    });
  }
}

class NutritionNotifier extends StateNotifier<List<MealItem>> {
  NutritionNotifier()
    : super([
        MealItem(
          id: "m1",
          name: "Oatmeal with Whey & Berries",
          mealType: "Breakfast",
          calories: 420,
          protein: 32,
          carbs: 55,
          fat: 8,
        ),
        MealItem(
          id: "m2",
          name: "Grilled Chicken Salad with Avocado",
          mealType: "Lunch",
          calories: 550,
          protein: 48,
          carbs: 18,
          fat: 26,
        ),
      ]);

  void addMeal(MealItem meal) {
    state = [...state, meal];
  }

  void removeMeal(String id) {
    state = state.where((m) => m.id != id).toList();
  }

  int get totalCalories => state.fold(0, (sum, m) => sum + m.calories);
  int get totalProtein => state.fold(0, (sum, m) => sum + m.protein);
  int get totalCarbs => state.fold(0, (sum, m) => sum + m.carbs);
  int get totalFat => state.fold(0, (sum, m) => sum + m.fat);
}

class CommunityNotifier extends StateNotifier<List<CommunityPost>> {
  CommunityNotifier()
    : super([
        CommunityPost(
          id: "p1",
          userName: "Sarah Jenkins",
          userAvatar:
              "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80",
          timeAgo: "2 hours ago",
          content:
              "Hit my personal deadlift PR today! 140kg for 3 reps! Highly recommend the Strength Power program on Elite Fitness. Let's keep pushing! 🚀💥",
          imagePath:
              "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80",
          likes: 42,
          commentsCount: 8,
        ),
        CommunityPost(
          id: "p2",
          userName: "David K.",
          userAvatar:
              "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80",
          timeAgo: "5 hours ago",
          content:
              "AI Coach suggested a post-workout recovery stretching routine. Honestly, my hamstrings feel 10x better. Consistency pays off!",
          likes: 18,
          commentsCount: 2,
        ),
      ]);

  void toggleLike(String id) {
    state = state.map((post) {
      if (post.id == id) {
        final newIsLiked = !post.isLiked;
        return CommunityPost(
          id: post.id,
          userName: post.userName,
          userAvatar: post.userAvatar,
          timeAgo: post.timeAgo,
          content: post.content,
          imagePath: post.imagePath,
          likes: newIsLiked ? post.likes + 1 : post.likes - 1,
          commentsCount: post.commentsCount,
          isLiked: newIsLiked,
        );
      }
      return post;
    }).toList();
  }

  void addPost(String content) {
    final newPost = CommunityPost(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      userName: "Alex Mercer",
      userAvatar:
          "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
      timeAgo: "Just now",
      content: content,
      likes: 0,
      commentsCount: 0,
    );
    state = [newPost, ...state];
  }
}

// --- GLOBAL RIVERPOD PROVIDERS ---

final userProfileProvider =
    StateNotifierProvider<UserProfileNotifier, UserProfile>((ref) {
      return UserProfileNotifier();
    });

final dailyTrackerProvider =
    StateNotifierProvider<DailyTrackerNotifier, DailyTracker>((ref) {
      return DailyTrackerNotifier();
    });

final workoutsProvider =
    StateNotifierProvider<WorkoutsNotifier, List<WorkoutItem>>((ref) {
      return WorkoutsNotifier();
    });

final chatProvider = StateNotifierProvider<ChatNotifier, List<ChatMessage>>((
  ref,
) {
  return ChatNotifier();
});

final nutritionProvider =
    StateNotifierProvider<NutritionNotifier, List<MealItem>>((ref) {
      return NutritionNotifier();
    });

final communityProvider =
    StateNotifierProvider<CommunityNotifier, List<CommunityPost>>((ref) {
      return CommunityNotifier();
    });

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier() : super(ThemeMode.dark);

  void toggleTheme(bool isDark) {
    state = isDark ? ThemeMode.dark : ThemeMode.light;
  }
}

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((
  ref,
) {
  return ThemeModeNotifier();
});
