package com.elite.fitness.elite_fitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
