package com.example.router_use

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
