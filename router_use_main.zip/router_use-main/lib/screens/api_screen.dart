import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ApiScreen extends StatefulWidget {
  const ApiScreen({super.key});

  @override
  State<ApiScreen> createState() =>
      _ApiScreenState();
}

class _ApiScreenState extends State<ApiScreen> {
  final ApiService apiService =
      ApiService();

  List posts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadPosts();
  }

  Future<void> loadPosts() async {
    try {
      posts = await apiService.fetchPosts();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  Color getColor(int index) {
    List<Color> colors = [
      Colors.blue,
      Colors.purple,
      Colors.orange,
      Colors.green,
      Colors.teal,
    ];

    return colors[index % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xffF4F6FD),

      appBar: AppBar(
        title: const Text("API Posts"),
        backgroundColor:
            const Color(0xff4F46E5),
        foregroundColor: Colors.white,
        elevation: 0,
      ),

      body: Column(
        children: [

       
          Container(
            height: 180,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xff4F46E5),
                  Color(0xff7C3AED),
                ],
              ),
              borderRadius:
                  BorderRadius.only(
                bottomLeft:
                    Radius.circular(40),
                bottomRight:
                    Radius.circular(40),
              ),
            ),

            child: const Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [

                Icon(
                  Icons.cloud,
                  color: Colors.white,
                  size: 65,
                ),

                SizedBox(height: 10),

                Text(
                  "JSON API Posts",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          Expanded(
            child: isLoading
                ? const Center(
                    child:
                        CircularProgressIndicator(),
                  )
                : ListView.builder(
                    itemCount:
                        posts.length,
                    itemBuilder:
                        (context, index) {

                      return Card(
                        margin:
                            const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 8,
                        ),

                        elevation: 5,

                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(
                                  20),
                        ),

                        child: Padding(
                          padding:
                              const EdgeInsets.all(
                                  15),

                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,

                            children: [

                              Row(
                                children: [

                                  CircleAvatar(
                                    backgroundColor:
                                        getColor(
                                            index),
                                    child: Text(
                                      "${posts[index]['id']}",
                                      style:
                                          const TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),

                                  const SizedBox(
                                      width: 10),

                                  Expanded(
                                    child: Text(
                                      posts[index]
                                          ['title'],
                                      style:
                                          const TextStyle(
                                        fontSize: 18,
                                        fontWeight:
                                            FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(
                                  height: 15),

                              Text(
                                posts[index]
                                    ['body'],
                                style:
                                    const TextStyle(
                                  fontSize: 15,
                                  color:
                                      Colors.black87,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}