import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

class FileScreen extends StatefulWidget {
  const FileScreen({super.key});

  @override
  State<FileScreen> createState() => _FileScreenState();
}

class _FileScreenState extends State<FileScreen> {
  String fileName = "";
  String fileSize = "";
  String fileExtension = "";

  Future<void> pickFile() async {
    FilePickerResult? result =
        await FilePicker.platform.pickFiles();

    if (result != null) {
      final file = result.files.first;

      setState(() {
        fileName = file.name;

        fileExtension =
            file.extension ?? "Unknown";

        double sizeKB = file.size / 1024;

        if (sizeKB < 1024) {
          fileSize =
              "${sizeKB.toStringAsFixed(2)} KB";
        } else {
          fileSize =
              "${(sizeKB / 1024).toStringAsFixed(2)} MB";
        }
      });
    }
  }

  IconData getFileIcon() {
    switch (fileExtension.toLowerCase()) {
      case "pdf":
        return Icons.picture_as_pdf;

      case "doc":
      case "docx":
        return Icons.description;

      case "jpg":
      case "jpeg":
      case "png":
        return Icons.image;

      case "mp4":
        return Icons.video_file;

      case "mp3":
        return Icons.audio_file;

      default:
        return Icons.insert_drive_file;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xffF4F6FD),

      appBar: AppBar(
        title: const Text("File Manager"),
        backgroundColor:
            const Color(0xff4F46E5),
        foregroundColor: Colors.white,
        elevation: 0,
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [

            /// Header
            Container(
              height: 180,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff4F46E5),
                    Color(0xff7C3AED),
                  ],
                ),
                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),
                  bottomRight:
                      Radius.circular(40),
                ),
              ),
              child: const Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [

                  Icon(
                    Icons.folder,
                    color: Colors.white,
                    size: 70,
                  ),

                  SizedBox(height: 10),

                  Text(
                    "File Manager",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),

            fileName.isEmpty
                ? Container(
                    height: 250,
                    width: 320,
                    decoration:
                        BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.circular(
                              25),
                      boxShadow: [
                        BoxShadow(
                          color:
                              Colors.black12,
                          blurRadius: 10,
                          offset:
                              const Offset(
                                  0, 5),
                        ),
                      ],
                    ),
                    child: const Column(
                      mainAxisAlignment:
                          MainAxisAlignment
                              .center,
                      children: [

                        Icon(
                          Icons.upload_file,
                          size: 100,
                          color: Colors.grey,
                        ),

                        SizedBox(height: 20),

                        Text(
                          "No File Selected",
                          style: TextStyle(
                            fontSize: 20,
                            color:
                                Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  )

                : Card(
                    margin:
                        const EdgeInsets.all(
                            20),
                    elevation: 8,
                    shape:
                        RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(
                              25),
                    ),
                    child: Padding(
                      padding:
                          const EdgeInsets.all(
                              20),
                      child: Column(
                        children: [

                          Icon(
                            getFileIcon(),
                            size: 80,
                            color:
                                Colors.deepPurple,
                          ),

                          const SizedBox(
                              height: 20),

                          Text(
                            fileName,
                            textAlign:
                                TextAlign.center,
                            style:
                                const TextStyle(
                              fontSize: 20,
                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),

                          const SizedBox(
                              height: 20),

                          ListTile(
                            leading:
                                const Icon(
                              Icons
                                  .data_usage,
                              color:
                                  Colors.blue,
                            ),
                            title:
                                const Text(
                                    "File Size"),
                            subtitle:
                                Text(
                                    fileSize),
                          ),

                          const Divider(),

                          ListTile(
                            leading:
                                const Icon(
                              Icons.file_copy,
                              color:
                                  Colors.green,
                            ),
                            title:
                                const Text(
                                    "Extension"),
                            subtitle: Text(
                              fileExtension
                                  .toUpperCase(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: pickFile,
              icon:
                  const Icon(Icons.upload),
              label: Text(
                fileName.isEmpty
                    ? "Pick File"
                    : "Choose Another File",
              ),
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    Colors.deepPurple,
                foregroundColor:
                    Colors.white,
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(
                          30),
                ),
              ),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}