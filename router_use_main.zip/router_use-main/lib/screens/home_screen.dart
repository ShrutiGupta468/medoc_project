import 'package:flutter/material.dart';
import '../utils/user_data.dart';
import 'profile_screen.dart';
import 'camera_screen.dart';
import 'file_screen.dart';
import 'api_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() =>
      _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  Future<void> openScreen(Widget screen) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => screen,
      ),
    );

    setState(() {});
  }

  Widget dashboardCard(
    String title,
    IconData icon,
    Color color,
    Widget screen,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(25),
      onTap: () {
        openScreen(screen);
      },
      child: Container(
        height: 160,
        width: 160,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(
            colors: [
              color,
              color.withOpacity(0.8),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 8),
            )
          ],
        ),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 55,
              color: Colors.white,
            ),
            const SizedBox(height: 15),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight:
                    FontWeight.bold,
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xffF4F6FD),

      body: SafeArea(
        child: Column(
          children: [

            /// Header
            Container(
              height: 220,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff4F46E5),
                    Color(0xff7C3AED),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),
                  bottomRight:
                      Radius.circular(40),
                ),
              ),

              child: Padding(
                padding:
                    const EdgeInsets.all(20),

                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [

                    Row(
                      children: [

                        CircleAvatar(
                          radius: 32,
                          backgroundColor:
                              Colors.white,
                          backgroundImage:
                              UserData.profileImage != null
                                  ? FileImage(
                                      UserData.profileImage!,
                                    )
                                  : null,
                          child:
                              UserData.profileImage == null
                                  ? const Icon(
                                      Icons.person,
                                      size: 35,
                                      color: Colors.deepPurple,
                                    )
                                  : null,
                        ),

                        const Spacer(),

                        Container(
                          padding:
                              const EdgeInsets.all(10),
                          decoration:
                              BoxDecoration(
                            color: Colors.white24,
                            borderRadius:
                                BorderRadius.circular(15),
                          ),
                          child: const Icon(
                            Icons.notifications,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 25),

                    const Text(
                      "Hello Student 👋",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 5),

                    const Text(
                      "Welcome Back",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),

            const Padding(
              padding:
                  EdgeInsets.symmetric(
                horizontal: 20,
              ),
              child: Align(
                alignment:
                    Alignment.centerLeft,
                child: Text(
                  "Features",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: GridView.count(
                padding:
                    const EdgeInsets.all(20),
                crossAxisCount: 2,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,

                children: [

                  dashboardCard(
                    "Profile",
                    Icons.person,
                    Colors.blue,
                    const ProfileScreen(),
                  ),

                  dashboardCard(
                    "Camera",
                    Icons.camera_alt,
                    Colors.orange,
                    const CameraScreen(),
                  ),

                  dashboardCard(
                    "Documents",
                    Icons.folder,
                    Colors.green,
                    const FileScreen(),
                  ),

                  dashboardCard(
                    "API Data",
                    Icons.cloud,
                    Colors.purple,
                    const ApiScreen(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}