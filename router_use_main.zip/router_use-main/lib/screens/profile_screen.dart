import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../utils/user_data.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() =>
      _ProfileScreenState();
}

class _ProfileScreenState
    extends State<ProfileScreen> {

  File? image;

  Future pickImage() async {
    final picked =
        await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );

    if (picked != null) {
      setState(() {
        image = File(picked.path);
        UserData.profileImage = image;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    image = UserData.profileImage;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xffF4F6FD),

      appBar: AppBar(
        title: const Text("Profile"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [

            Container(
              height: 250,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff4F46E5),
                    Color(0xff7C3AED),
                  ],
                ),
                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),
                  bottomRight:
                      Radius.circular(40),
                ),
              ),

              child: Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [

                  Stack(
                    children: [
                      CircleAvatar(
                        radius: 70,
                        backgroundColor:
                            Colors.white,
                        backgroundImage:
                            image != null
                                ? FileImage(
                                    image!)
                                : null,
                        child: image == null
                            ? const Icon(
                                Icons.person,
                                size: 70,
                                color:
                                    Colors.grey,
                              )
                            : null,
                      ),

                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: InkWell(
                          onTap: pickImage,
                          child: Container(
                            padding:
                                const EdgeInsets
                                    .all(8),
                            decoration:
                                const BoxDecoration(
                              color:
                                  Colors.white,
                              shape:
                                  BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt,
                              color: Colors
                                  .deepPurple,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),

                  const SizedBox(height: 15),

                  const Text(
                    "Student Name",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const Text(
                    "Flutter Developer",
                    style: TextStyle(
                      color:
                          Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            Card(
              margin:
                  const EdgeInsets.all(20),
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(
                        20),
              ),
              elevation: 5,
              child: Padding(
                padding:
                    const EdgeInsets.all(
                        20),
                child: Column(
                  children: [

                    ListTile(
                      leading:
                          const Icon(
                        Icons.email,
                        color:
                            Colors.blue,
                      ),
                      title: const Text(
                          "Email"),
                      subtitle:
                          const Text(
                        "student@gmail.com",
                      ),
                    ),

                    const Divider(),

                    ListTile(
                      leading:
                          const Icon(
                        Icons.phone,
                        color:
                            Colors.green,
                      ),
                      title: const Text(
                          "Phone"),
                      subtitle:
                          const Text(
                        "+91 XXXXX XXXXX",
                      ),
                    ),

                    const Divider(),

                    ListTile(
                      leading:
                          const Icon(
                        Icons.school,
                        color:
                            Colors.orange,
                      ),
                      title: const Text(
                          "Course"),
                      subtitle:
                          const Text(
                        "B.Tech CSE",
                      ),
                    ),
                  ],
                ),
              ),
            ),

            ElevatedButton.icon(
              onPressed: pickImage,
              icon:
                  const Icon(Icons.photo),
              label:
                  const Text("Change Photo"),
            )
          ],
        ),
      ),
    );
  }
}