import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ForgotPasswordPage
    extends StatefulWidget {

  const ForgotPasswordPage({
    super.key,
  });

  @override
  State<ForgotPasswordPage>
      createState() =>
          _ForgotPasswordPageState();
}

class _ForgotPasswordPageState
    extends State<ForgotPasswordPage> {

  final _formKey =
      GlobalKey<FormState>();

  final TextEditingController
      emailController =
      TextEditingController();

  bool emailSent = false;

  bool isLoading = false;

  // 🔷 SUPABASE CLIENT
  final supabase =
      Supabase.instance.client;

  // 🔷 SEND RESET LINK
  Future<void> sendResetLink() async {

    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      // 🔷 SUPABASE RESET PASSWORD
      await supabase.auth
          .resetPasswordForEmail(

        emailController.text.trim(),

        // OPTIONAL REDIRECT URL
        redirectTo:
            'io.supabase.flutter://reset-callback',
      );

      setState(() {
        emailSent = true;
      });

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Password reset link sent successfully",
          ),
        ),
      );

    } on AuthException catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            e.message,
          ),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F6FA),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔷 TOP HEADER
            Container(
              width: double.infinity,

              padding:
                  const EdgeInsets.only(
                top: 85,
                bottom: 45,
              ),

              decoration:
                  const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF6A5AE0),
                    Color(0xFF8E7CFF),
                  ],
                ),

                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),

                  bottomRight:
                      Radius.circular(40),
                ),
              ),

              child: Column(
                children: [

                  // 🔷 ICON
                  Container(
                    padding:
                        const EdgeInsets.all(
                            22),

                    decoration:
                        BoxDecoration(
                      color: Colors.white,

                      borderRadius:
                          BorderRadius
                              .circular(28),
                    ),

                    child: const Icon(
                      Icons.lock_reset,

                      size: 65,

                      color:
                          Color(0xFF6A5AE0),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Forgot Password",

                    style: TextStyle(
                      color: Colors.white,

                      fontSize: 30,

                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  const Padding(
                    padding:
                        EdgeInsets.symmetric(
                            horizontal: 30),

                    child: Text(
                      "Enter your registered email address to receive a password reset link.",

                      textAlign:
                          TextAlign.center,

                      style: TextStyle(
                        color:
                            Colors.white70,

                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 35),

            // 🔷 FORM CARD
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),

              child: Container(
                padding:
                    const EdgeInsets.all(
                        25),

                decoration:
                    BoxDecoration(
                  color: Colors.white,

                  borderRadius:
                      BorderRadius.circular(
                          30),

                  boxShadow: [
                    BoxShadow(
                      color:
                          Colors.grey.shade200,

                      blurRadius: 15,
                    ),
                  ],
                ),

                child: Form(
                  key: _formKey,

                  child: Column(
                    children: [

                      // 🔷 EMAIL FIELD
                      Container(
                        decoration:
                            BoxDecoration(
                          color: Colors
                              .grey.shade100,

                          borderRadius:
                              BorderRadius
                                  .circular(
                                      22),
                        ),

                        child:
                            TextFormField(
                          controller:
                              emailController,

                          validator:
                              (value) {

                            if (value ==
                                    null ||
                                value
                                    .isEmpty) {
                              return "Email is required";
                            }

                            if (!value
                                .contains(
                                    "@")) {
                              return "Enter valid email";
                            }

                            return null;
                          },

                          decoration:
                              const InputDecoration(
                            hintText:
                                "Enter Email",

                            prefixIcon:
                                Icon(
                              Icons.email,

                              color: Color(
                                  0xFF6A5AE0),
                            ),

                            border:
                                InputBorder
                                    .none,

                            contentPadding:
                                EdgeInsets.all(
                                    20),
                          ),
                        ),
                      ),

                      const SizedBox(
                          height: 30),

                      // 🔷 SEND BUTTON
                      SizedBox(
                        width:
                            double.infinity,

                        height: 58,

                        child:
                            ElevatedButton(
                          style:
                              ElevatedButton
                                  .styleFrom(
                            backgroundColor:
                                const Color(
                                    0xFF6A5AE0),

                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(
                                      18),
                            ),

                            elevation: 5,
                          ),

                          onPressed:
                              isLoading
                                  ? null
                                  : sendResetLink,

                          child:
                              isLoading
                                  ? const CircularProgressIndicator(
                                      color:
                                          Colors.white,
                                    )
                                  : const Text(
                                      "Send Reset Link",

                                      style:
                                          TextStyle(
                                        fontSize:
                                            18,

                                        color:
                                            Colors.white,

                                        fontWeight:
                                            FontWeight
                                                .bold,
                                      ),
                                    ),
                        ),
                      ),

                      const SizedBox(
                          height: 25),

                      // 🔷 SUCCESS MESSAGE
                      if (emailSent)
                        Container(
                          padding:
                              const EdgeInsets
                                  .all(18),

                          decoration:
                              BoxDecoration(
                            color: Colors
                                .green
                                .shade50,

                            borderRadius:
                                BorderRadius
                                    .circular(
                                        20),
                          ),

                          child: Row(
                            children: [

                              const Icon(
                                Icons
                                    .check_circle,

                                color: Colors
                                    .green,
                              ),

                              const SizedBox(
                                  width: 12),

                              Expanded(
                                child: Text(
                                  "Reset link has been sent to your email.",

                                  style:
                                      TextStyle(
                                    color: Colors
                                        .grey
                                        .shade700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                      const SizedBox(
                          height: 25),

                      // 🔷 BACK TO LOGIN
                      Row(
                        mainAxisAlignment:
                            MainAxisAlignment
                                .center,

                        children: [

                          const Text(
                            "Remember password? ",
                          ),

                          GestureDetector(
                            onTap: () {
                              Navigator.pop(
                                  context);
                            },

                            child:
                                const Text(
                              "Login",

                              style:
                                  TextStyle(
                                color: Color(
                                    0xFF6A5AE0),

                                fontWeight:
                                    FontWeight
                                        .bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}