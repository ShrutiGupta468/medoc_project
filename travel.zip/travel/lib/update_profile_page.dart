import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UpdateProfilePage extends StatefulWidget {
  const UpdateProfilePage({super.key});

  @override
  State<UpdateProfilePage> createState() =>
      _UpdateProfilePageState();
}

class _UpdateProfilePageState
    extends State<UpdateProfilePage> {

  final supabase = Supabase.instance.client;

  final TextEditingController nameController =
      TextEditingController();

  final TextEditingController emailController =
      TextEditingController();

  final TextEditingController phoneController =
      TextEditingController();

  final TextEditingController bioController =
      TextEditingController();

  String selectedGender = "Male";

  bool isLoading = false;

  Uint8List? selectedImage;

  String? imageUrl;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  // 🔷 LOAD PROFILE
  Future<void> loadProfile() async {

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) return;

      final data = await supabase
          .from('profiles')
          .select()
          .eq('id', user.id)
          .maybeSingle();

      if (data != null) {

        setState(() {

          nameController.text =
              data['full_name'] ?? '';

          emailController.text =
              data['email'] ?? '';

          phoneController.text =
              data['phone'] ?? '';

          bioController.text =
              data['bio'] ?? '';

          selectedGender =
              data['gender'] ?? 'Male';

          imageUrl =
              data['avatar_url'];
        });
      }

    } catch (e) {

      print(
        "LOAD PROFILE ERROR:",
      );

      print(e.toString());
    }
  }

  // 🔷 PICK IMAGE
  Future<void> pickImage() async {

    try {

      final picker = ImagePicker();

      final pickedFile =
          await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
      );

      if (pickedFile != null) {

        final bytes =
            await pickedFile.readAsBytes();

        setState(() {
          selectedImage = bytes;
        });

        print(
          "IMAGE PICKED",
        );
      }

    } catch (e) {

      print(
        "IMAGE PICK ERROR:",
      );

      print(e.toString());
    }
  }

  // 🔷 UPLOAD IMAGE
  Future<String?> uploadImage() async {

    try {

      if (selectedImage == null) {
        return imageUrl;
      }

      final user =
          supabase.auth.currentUser;

      if (user == null) return null;

      final fileName =
          "${user.id}_${DateTime.now().microsecondsSinceEpoch}.png";

      // 🔷 UPLOAD
      await supabase.storage
          .from('profile pictures')
          .uploadBinary(
            fileName,
            selectedImage!,
            fileOptions:
                const FileOptions(
              upsert: true,
              contentType:
                  'image/png',
            ),
          );

      // 🔷 GET PUBLIC URL
      final publicUrl =
          supabase.storage
              .from(
                'profile-pictures',
              )
              .getPublicUrl(
                fileName,
              );

      print(
        "IMAGE URL:",
      );

      print(publicUrl);

      return publicUrl;

    } catch (e) {

      print(
        "UPLOAD ERROR:",
      );

      print(e.toString());

      return null;
    }
  }

  // 🔷 SAVE PROFILE
  Future<void> saveProfile() async {

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) {

        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              "User not logged in",
            ),
          ),
        );

        return;
      }

      if (nameController.text.isEmpty ||
          emailController.text.isEmpty ||
          phoneController.text.isEmpty) {

        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              "Please fill all required fields",
            ),
          ),
        );

        return;
      }

      setState(() {
        isLoading = true;
      });

      // 🔷 UPLOAD IMAGE
      String? uploadedImageUrl =
          await uploadImage();

      // 🔷 SAVE DATA
      await supabase
          .from('profiles')
          .upsert({

        'id': user.id,

        'full_name':
            nameController.text.trim(),

        'email':
            emailController.text.trim(),

        'phone':
            phoneController.text.trim(),

        'bio':
            bioController.text.trim(),

        'gender':
            selectedGender,

        'avatar_url':
            uploadedImageUrl,
      });

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Profile Updated Successfully",
          ),
        ),
      );

      Navigator.pop(context, true);

    } catch (e) {

      print(
        "SAVE PROFILE ERROR:",
      );

      print(e.toString());

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            "Error: $e",
          ),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F6FA),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔷 HEADER
            Container(
              width: double.infinity,

              padding:
                  const EdgeInsets.only(
                top: 60,
                bottom: 30,
              ),

              decoration:
                  const BoxDecoration(
                gradient:
                    LinearGradient(
                  colors: [
                    Color(0xFF6A5AE0),
                    Color(0xFF8E7CFF),
                  ],
                ),

                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(35),

                  bottomRight:
                      Radius.circular(35),
                ),
              ),

              child: Column(
                children: [

                  // 🔷 BACK BUTTON
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 20,
                    ),

                    child: Row(
                      children: [

                        GestureDetector(
                          onTap: () {
                            Navigator.pop(
                                context);
                          },

                          child:
                              const CircleAvatar(
                            backgroundColor:
                                Colors.white24,

                            child: Icon(
                              Icons.arrow_back,
                              color:
                                  Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                      height: 20),

                  // 🔷 PROFILE IMAGE
                  Stack(
                    children: [

                      CircleAvatar(
                        radius: 55,

                        backgroundColor:
                            Colors.white,

                        backgroundImage:
                            selectedImage != null

                                ? MemoryImage(
                                        selectedImage!)
                                    as ImageProvider

                                : imageUrl !=
                                            null &&
                                        imageUrl!
                                            .isNotEmpty

                                    ? NetworkImage(
                                            imageUrl!)
                                        as ImageProvider

                                    : null,

                        child: selectedImage ==
                                    null &&
                                (imageUrl ==
                                        null ||
                                    imageUrl!
                                        .isEmpty)

                            ? const Icon(
                                Icons.person,
                                size: 50,
                                color:
                                    Colors.grey,
                              )

                            : null,
                      ),

                      Positioned(
                        bottom: 0,
                        right: 0,

                        child:
                            GestureDetector(
                          onTap: pickImage,

                          child: Container(
                            padding:
                                const EdgeInsets.all(
                              8,
                            ),

                            decoration:
                                BoxDecoration(
                              color:
                                  Colors.white,

                              borderRadius:
                                  BorderRadius.circular(
                                15,
                              ),
                            ),

                            child:
                                const Icon(
                              Icons.camera_alt,
                              color:
                                  Colors.deepPurple,
                              size: 20,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                      height: 15),

                  const Text(
                    "Update Profile",

                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(
                      height: 5),

                  const Text(
                    "Edit your personal information",

                    style: TextStyle(
                      color:
                          Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // 🔷 FORM
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),

              child: Column(
                children: [

                  _buildTextField(
                    controller:
                        nameController,
                    label: "Full Name",
                    icon: Icons.person,
                  ),

                  const SizedBox(
                      height: 18),

                  _buildTextField(
                    controller:
                        emailController,
                    label:
                        "Email Address",
                    icon: Icons.email,
                  ),

                  const SizedBox(
                      height: 18),

                  _buildTextField(
                    controller:
                        phoneController,
                    label:
                        "Phone Number",
                    icon: Icons.phone,
                  ),

                  const SizedBox(
                      height: 18),

                  _buildTextField(
                    controller:
                        bioController,
                    label: "Bio",
                    icon:
                        Icons.edit_note,
                    maxLines: 3,
                  ),

                  const SizedBox(
                      height: 20),

                  // 🔷 GENDER
                  Container(
                    padding:
                        const EdgeInsets.all(
                      18,
                    ),

                    decoration:
                        BoxDecoration(
                      color: Colors.white,

                      borderRadius:
                          BorderRadius.circular(
                        22,
                      ),

                      boxShadow: [

                        BoxShadow(
                          color: Colors
                              .grey.shade200,

                          blurRadius: 10,
                        ),
                      ],
                    ),

                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [

                        const Text(
                          "Gender",

                          style: TextStyle(
                            fontWeight:
                                FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),

                        const SizedBox(
                            height: 10),

                        Row(
                          children: [

                            Expanded(
                              child:
                                  _genderButton(
                                "Male",
                              ),
                            ),

                            const SizedBox(
                                width: 10),

                            Expanded(
                              child:
                                  _genderButton(
                                "Female",
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                      height: 30),

                  // 🔷 SAVE BUTTON
                  SizedBox(
                    width:
                        double.infinity,

                    height: 58,

                    child:
                        ElevatedButton(
                      style:
                          ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color(
                          0xFF6A5AE0,
                        ),

                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(
                            18,
                          ),
                        ),

                        elevation: 5,
                      ),

                      onPressed:
                          isLoading
                              ? null
                              : saveProfile,

                      child:
                          isLoading

                              ? const CircularProgressIndicator(
                                  color:
                                      Colors.white,
                                )

                              : const Text(
                                  "Save Changes",

                                  style:
                                      TextStyle(
                                    fontSize:
                                        18,
                                    color:
                                        Colors.white,
                                    fontWeight:
                                        FontWeight.bold,
                                  ),
                                ),
                    ),
                  ),

                  const SizedBox(
                      height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔷 CUSTOM TEXTFIELD
  Widget _buildTextField({
    required TextEditingController
        controller,

    required String label,

    required IconData icon,

    int maxLines = 1,
  }) {

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
          22,
        ),

        boxShadow: [

          BoxShadow(
            color:
                Colors.grey.shade200,

            blurRadius: 10,
          ),
        ],
      ),

      child: TextField(
        controller: controller,
        maxLines: maxLines,

        decoration: InputDecoration(
          prefixIcon: Icon(
            icon,
            color:
                Colors.deepPurple,
          ),

          labelText: label,

          border: InputBorder.none,

          contentPadding:
              const EdgeInsets.all(
            20,
          ),
        ),
      ),
    );
  }

  // 🔷 GENDER BUTTON
  Widget _genderButton(
      String gender) {

    bool isSelected =
        selectedGender == gender;

    return GestureDetector(
      onTap: () {

        setState(() {
          selectedGender = gender;
        });
      },

      child: AnimatedContainer(
        duration:
            const Duration(
          milliseconds: 250,
        ),

        padding:
            const EdgeInsets.symmetric(
          vertical: 14,
        ),

        decoration: BoxDecoration(
          color: isSelected
              ? const Color(
                  0xFF6A5AE0,
                )
              : Colors.grey.shade100,

          borderRadius:
              BorderRadius.circular(
            15,
          ),
        ),

        child: Center(
          child: Text(
            gender,

            style: TextStyle(
              color: isSelected
                  ? Colors.white
                  : Colors.black87,

              fontWeight:
                  FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}