import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'models/diary_model.dart';
import 'add_diary_page.dart';

class DiaryPage extends StatefulWidget {
  const DiaryPage({super.key});

  @override
  State<DiaryPage> createState() =>
      _DiaryPageState();
}

class _DiaryPageState
    extends State<DiaryPage> {

  List<Map<String, dynamic>>
      diaryList = [];

  bool isLoading = true;

  final supabase =
      Supabase.instance.client;

  @override
  void initState() {
    super.initState();

    fetchDiaryEntries();
  }

  // 🔷 FETCH USER DIARY
  Future<void>
      fetchDiaryEntries() async {

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) return;

      final data = await supabase
          .from('travel_diary')
          .select()
          .eq('user_id', user.id)
          .order(
            'created_at',
            ascending: false,
          );

      setState(() {
        diaryList =
            List<Map<String, dynamic>>
                .from(data);

        isLoading = false;
      });

    } catch (e) {

      setState(() {
        isLoading = false;
      });
    }
  }

  // 🔷 ADD ENTRY
  Future<void> addEntry(
    DiaryModel entry,
  ) async {

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) return;

      await supabase
          .from('travel_diary')
          .insert({

        'user_id': user.id,

        'title': entry.title,

        'description':
            entry.description,

        'image': entry.image,

        'location':
            entry.location,

        'latitude':
            entry.latitude,

        'longitude':
            entry.longitude,
      });

      fetchDiaryEntries();

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content:
              Text(e.toString()),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFFF4F6FA),

      appBar: AppBar(
        title:
            const Text("Travel Diary 📖"),

        backgroundColor:
            Colors.deepPurple,
      ),

      body: isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(),
            )
          : diaryList.isEmpty
              ? const Center(
                  child: Text(
                    "No entries yet 😕",
                  ),
                )
              : ListView.builder(
                  padding:
                      const EdgeInsets.all(
                          16),

                  itemCount:
                      diaryList.length,

                  itemBuilder:
                      (context, index) {

                    final item =
                        diaryList[index];

                    final createdAt =
                        DateTime.parse(
                      item['created_at'],
                    );

                    return Container(
                      margin:
                          const EdgeInsets
                              .only(
                        bottom: 16,
                      ),

                      decoration:
                          BoxDecoration(
                        borderRadius:
                            BorderRadius
                                .circular(
                                    20),

                        boxShadow: [
                          BoxShadow(
                            color: Colors
                                .grey
                                .shade200,

                            blurRadius:
                                10,
                          ),
                        ],
                      ),

                      child: ClipRRect(
                        borderRadius:
                            BorderRadius
                                .circular(
                                    20),

                        child: Stack(
                          children: [

                            Image.network(
                              item['image'],

                              height: 180,

                              width:
                                  double.infinity,

                              fit:
                                  BoxFit.cover,
                            ),

                            Container(
                              height: 180,

                              decoration:
                                  BoxDecoration(
                                gradient:
                                    LinearGradient(
                                  colors: [
                                    Colors
                                        .black
                                        .withOpacity(
                                            0.7),

                                    Colors
                                        .transparent,
                                  ],

                                  begin:
                                      Alignment
                                          .bottomCenter,

                                  end:
                                      Alignment
                                          .topCenter,
                                ),
                              ),
                            ),

                            Positioned(
                              bottom: 10,
                              left: 10,
                              right: 10,

                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,

                                children: [

                                  Text(
                                    item[
                                        'title'],

                                    style:
                                        const TextStyle(
                                      color:
                                          Colors
                                              .white,

                                      fontSize:
                                          18,

                                      fontWeight:
                                          FontWeight
                                              .bold,
                                    ),
                                  ),

                                  Text(
                                    "${item['location']} • ${createdAt.day}/${createdAt.month}/${createdAt.year} • ${createdAt.hour}:${createdAt.minute}",

                                    style:
                                        const TextStyle(
                                      color:
                                          Colors
                                              .white70,
                                    ),
                                  ),

                                  Text(
                                    item[
                                        'description'],

                                    maxLines:
                                        2,

                                    overflow:
                                        TextOverflow
                                            .ellipsis,

                                    style:
                                        const TextStyle(
                                      color:
                                          Colors
                                              .white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),

      floatingActionButton:
          FloatingActionButton
              .extended(
        backgroundColor:
            Colors.deepPurple,

        onPressed: () async {

          final newEntry =
              await Navigator.push(
            context,

            MaterialPageRoute(
              builder: (_) =>
                  const AddDiaryPage(),
            ),
          );

          if (newEntry != null) {

            await addEntry(
              newEntry,
            );
          }
        },

        icon: const Icon(Icons.add),

        label:
            const Text("Add Entry"),
      ),
    );
  }
}