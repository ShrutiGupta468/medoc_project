import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'emergency_data.dart';

class SafetyPage extends StatelessWidget {
  const SafetyPage({super.key});

  // 📞 CALL FIRST EMERGENCY CONTACT
  Future<void> callEmergencyContact(
      BuildContext context) async {

    if (EmergencyData.emergencyNumbers.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              "No emergency contacts selected"),
        ),
      );

      return;
    }

    final number =
        EmergencyData.emergencyNumbers.first;

    final Uri uri = Uri(
      scheme: 'tel',
      path: number,
    );

    await launchUrl(uri);
  }

  // 📍 SHARE LIVE LOCATION
  Future<void> shareLocation(
      BuildContext context) async {

    if (EmergencyData.emergencyNumbers.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              "No emergency contacts selected"),
        ),
      );

      return;
    }

    LocationPermission permission;

    permission =
        await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {

      permission =
          await Geolocator.requestPermission();
    }

    Position position =
        await Geolocator.getCurrentPosition();

    String locationLink =
        "https://www.google.com/maps/search/?api=1&query=${position.latitude},${position.longitude}";

    String message =
        "🚨 Emergency!\n\nHere is my live location:\n\n$locationLink";

    Share.share(message);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),

      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        centerTitle: true,
        iconTheme:
            const IconThemeData(color: Colors.black),

        title: const Text(
          "Emergency & Safety",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            // TOP CARD
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),

              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFFFF5F6D),
                    Color(0xFFFF9966),
                  ],
                ),

                borderRadius:
                    BorderRadius.circular(28),

                boxShadow: [
                  BoxShadow(
                    color:
                        Colors.red.withOpacity(0.25),
                    blurRadius: 15,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),

              child: Column(
                children: const [

                  CircleAvatar(
                    radius: 38,
                    backgroundColor: Colors.white,

                    child: Icon(
                      Icons.warning_amber_rounded,
                      size: 45,
                      color: Colors.red,
                    ),
                  ),

                  SizedBox(height: 18),

                  Text(
                    "Emergency Assistance",

                    textAlign: TextAlign.center,

                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),

                  SizedBox(height: 10),

                  Text(
                    "Quickly contact emergency services or share your live location with trusted contacts.",

                    textAlign: TextAlign.center,

                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white70,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 35),

            // 📞 CALL BUTTON
            _buildSafetyCard(
              icon: Icons.call,
              title: "Call Emergency Contact",

              subtitle:
                  "Instantly connect with your emergency contact for immediate help.",

              buttonText: "Call Now",

              buttonColor: Colors.red,

              onTap: () =>
                  callEmergencyContact(context),
            ),

            const SizedBox(height: 20),

            // 📍 LOCATION BUTTON
            _buildSafetyCard(
              icon: Icons.location_on,

              title: "Share Live Location",

              subtitle:
                  "Send your current live location to trusted people for safety.",

              buttonText: "Share Location",

              buttonColor: Colors.blue,

              onTap: () =>
                  shareLocation(context),
            ),

            const SizedBox(height: 20),

            // STAY SAFE CARD
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),

              decoration: BoxDecoration(
                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(25),

                boxShadow: [
                  BoxShadow(
                    color:
                        Colors.black.withOpacity(0.05),

                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),

              child: Column(
                children: [

                  const Icon(
                    Icons.shield,
                    size: 55,
                    color: Colors.green,
                  ),

                  const SizedBox(height: 15),

                  const Text(
                    "Stay Safe",

                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "Enable quick emergency access and keep your trusted contacts updated during travel.",

                    textAlign: TextAlign.center,

                    style: TextStyle(
                      color: Colors.grey.shade700,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSafetyCard({

    required IconData icon,
    required String title,
    required String subtitle,
    required String buttonText,
    required Color buttonColor,
    required VoidCallback onTap,

  }) {

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(24),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),

      child: Column(
        children: [

          CircleAvatar(
            radius: 34,

            backgroundColor:
                buttonColor.withOpacity(0.12),

            child: Icon(
              icon,
              color: buttonColor,
              size: 34,
            ),
          ),

          const SizedBox(height: 18),

          Text(
            title,

            textAlign: TextAlign.center,

            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          Text(
            subtitle,

            textAlign: TextAlign.center,

            style: TextStyle(
              fontSize: 15,
              color: Colors.grey.shade700,
              height: 1.5,
            ),
          ),

          const SizedBox(height: 22),

          SizedBox(
            width: double.infinity,
            height: 55,

            child: ElevatedButton.icon(

              style: ElevatedButton.styleFrom(
                elevation: 0,
                backgroundColor: buttonColor,

                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(16),
                ),
              ),

              onPressed: onTap,

              icon: Icon(
                icon,
                color: Colors.white,
              ),

              label: Text(
                buttonText,

                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}