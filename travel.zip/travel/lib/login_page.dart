import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'main_screen.dart';
import 'signup_page.dart';
import 'forgot_password_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() =>
      _LoginPageState();
}

class _LoginPageState
    extends State<LoginPage> {

  final TextEditingController
      emailController =
      TextEditingController();

  final TextEditingController
      passwordController =
      TextEditingController();

  bool obscurePassword = true;

  bool isLoading = false;

  final supabase =
      Supabase.instance.client;

  // 🔷 LOGIN FUNCTION
  Future<void> loginUser() async {

    String email =
        emailController.text.trim();

    String password =
        passwordController.text.trim();

    if (email.isEmpty ||
        password.isEmpty) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Please enter email and password",
          ),
        ),
      );

      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      // 🔷 LOGIN USER
      await supabase.auth
          .signInWithPassword(

        email: email,
        password: password,
      );

      // 🔷 CURRENT USER
      final user =
          supabase.auth.currentUser;

      print(user?.email);
      print(user?.id);

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Login Successful",
          ),
        ),
      );

      // 🔷 NAVIGATE
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) =>
              MainScreen(),
        ),
      );

    } on AuthException catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            e.message,
          ),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F6FA),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔷 HEADER
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(
                top: 90,
                bottom: 50,
              ),
              decoration:
                  const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF6A5AE0),
                    Color(0xFF8E7CFF),
                  ],
                ),
                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),
                  bottomRight:
                      Radius.circular(40),
                ),
              ),

              child: Column(
                children: [

                  Container(
                    padding:
                        const EdgeInsets.all(
                            25),
                    decoration:
                        BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.circular(
                              30),
                    ),
                    child: const Icon(
                      Icons.travel_explore,
                      size: 70,
                      color:
                          Color(0xFF6A5AE0),
                    ),
                  ),

                  const SizedBox(height: 25),

                  const Text(
                    "Welcome Back",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  const Text(
                    "Login to continue",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 35),

            // 🔷 FORM
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),

              child: Column(
                children: [

                  // 🔷 EMAIL
                  _buildTextField(
                    controller:
                        emailController,

                    hint:
                        "Email Address",

                    icon:
                        Icons.email,
                  ),

                  const SizedBox(height: 20),

                  // 🔷 PASSWORD
                  _buildPasswordField(),

                  const SizedBox(height: 15),

                  // 🔷 FORGOT PASSWORD
                  Align(
                    alignment:
                        Alignment.centerRight,

                    child: TextButton(
                      onPressed: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) =>
                                    ForgotPasswordPage(),
                          ),
                        );
                      },

                      child: const Text(
                        "Forgot Password?",

                        style: TextStyle(
                          color: Color(
                              0xFF6A5AE0),

                          fontWeight:
                              FontWeight.w600,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // 🔷 LOGIN BUTTON
                  SizedBox(
                    width: double.infinity,
                    height: 58,

                    child: ElevatedButton(
                      style:
                          ElevatedButton
                              .styleFrom(
                        backgroundColor:
                            const Color(
                                0xFF6A5AE0),

                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(
                                  18),
                        ),
                      ),

                      onPressed:
                          isLoading
                              ? null
                              : loginUser,

                      child:
                          isLoading
                              ? const CircularProgressIndicator(
                                  color:
                                      Colors.white,
                                )
                              : const Text(
                                  "Login",

                                  style:
                                      TextStyle(
                                    fontSize:
                                        18,

                                    color:
                                        Colors.white,

                                    fontWeight:
                                        FontWeight
                                            .bold,
                                  ),
                                ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // 🔷 SIGNUP
                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment
                            .center,

                    children: [

                      const Text(
                        "Don't have an account? ",
                      ),

                      GestureDetector(
                        onTap: () {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (context) =>
                                      SignupPage(),
                            ),
                          );
                        },

                        child: const Text(
                          "Sign Up",

                          style: TextStyle(
                            color: Color(
                                0xFF6A5AE0),

                            fontWeight:
                                FontWeight
                                    .bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔷 TEXT FIELD
  Widget _buildTextField({
    required TextEditingController
        controller,

    required String hint,

    required IconData icon,
  }) {

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(22),

        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
          ),
        ],
      ),

      child: TextField(
        controller: controller,

        decoration: InputDecoration(
          hintText: hint,

          prefixIcon: Icon(
            icon,

            color:
                const Color(0xFF6A5AE0),
          ),

          border: InputBorder.none,

          contentPadding:
              const EdgeInsets.all(20),
        ),
      ),
    );
  }

  // 🔷 PASSWORD FIELD
  Widget _buildPasswordField() {

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(22),

        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
          ),
        ],
      ),

      child: TextField(
        controller:
            passwordController,

        obscureText:
            obscurePassword,

        decoration: InputDecoration(
          hintText: "Password",

          prefixIcon: const Icon(
            Icons.lock,

            color:
                Color(0xFF6A5AE0),
          ),

          suffixIcon: IconButton(
            onPressed: () {

              setState(() {
                obscurePassword =
                    !obscurePassword;
              });
            },

            icon: Icon(
              obscurePassword
                  ? Icons
                      .visibility_off
                  : Icons.visibility,
            ),
          ),

          border: InputBorder.none,

          contentPadding:
              const EdgeInsets.all(20),
        ),
      ),
    );
  }
}