class DiaryModel {

  final String title;
  final String description;
  final String image;
  final String location;

  final double latitude;
  final double longitude;

  DiaryModel({

    required this.title,
    required this.description,
    required this.image,
    required this.location,
    required this.latitude,
    required this.longitude,
  });
}