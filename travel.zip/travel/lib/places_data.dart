// ==========================
// REPLACE COMPLETE places_data.dart
// ==========================

final List<Map<String, String>> beachPlaces = [

  {
    "name": "Baga Beach",
    "location": "Goa, India",
    "image":
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    "description":
        "Baga Beach is famous for nightlife, beach parties and water sports.",
  },

  {
    "name": "Marina Beach",
    "location": "Chennai, India",
    "image":
        "https://images.unsplash.com/photo-1473116763249-2faaef81ccda",
    "description":
        "Marina Beach is India's longest urban beach known for sunrise views.",
  },

  {
    "name": "Kovalam Beach",
    "location": "Kerala, India",
    "image":
        "https://images.unsplash.com/photo-1500375592092-40eb2168fd21",
    "description":
        "Kovalam Beach is popular for lighthouse views and relaxing resorts.",
  },

  {
    "name": "Palolem Beach",
    "location": "Goa, India",
    "image":
        "https://images.unsplash.com/photo-1493558103817-58b2924bce98",
    "description":
        "Palolem Beach is famous for calm waters and beautiful palm trees.",
  },

  {
    "name": "Varkala Beach",
    "location": "Kerala, India",
    "image":
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
    "description":
        "Varkala Beach is known for cliffs, cafes and Arabian Sea views.",
  },

  {
    "name": "Radhanagar Beach",
    "location": "Andaman, India",
    "image":
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb",
    "description":
        "Radhanagar Beach is famous for crystal clear water and white sand.",
  },

  {
    "name": "Puri Beach",
    "location": "Odisha, India",
    "image":
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
    "description":
        "Puri Beach is popular for golden sand and local seafood.",
  },

  {
    "name": "Tarkarli Beach",
    "location": "Maharashtra, India",
    "image":
        "https://images.unsplash.com/photo-1493558103817-58b2924bce98",
    "description":
        "Tarkarli Beach is known for scuba diving and clean beaches.",
  },

  {
    "name": "Digha Beach",
    "location": "West Bengal, India",
    "image":
        "https://images.unsplash.com/photo-1519046904884-53103b34b206",
    "description":
        "Digha Beach is a relaxing destination with beautiful sunset views.",
  },

  {
    "name": "Gokarna Beach",
    "location": "Karnataka, India",
    "image":
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    "description":
        "Gokarna Beach is famous for peaceful vibes and scenic beauty.",
  },
];

// ==========================
// MOUNTAINS
// ==========================

final List<Map<String, String>> mountainPlaces = [

  {
    "name": "Manali",
    "location": "Himachal Pradesh",
    "image":
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
    "description":
        "Manali is famous for snow mountains and adventure sports.",
  },

  {
    "name": "Leh Ladakh",
    "location": "Ladakh, India",
    "image":
        "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b",
    "description":
        "Leh Ladakh offers breathtaking mountain roads and monasteries.",
  },

  {
    "name": "Shimla",
    "location": "Himachal Pradesh",
    "image":
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
    "description":
        "Shimla is known for cool weather and colonial architecture.",
  },

  {
    "name": "Mussoorie",
    "location": "Uttarakhand",
    "image":
        "https://images.unsplash.com/photo-1441974231531-c6227db76b6e",
    "description":
        "Mussoorie is called the Queen of Hills with scenic mountain views.",
  },

  {
    "name": "Nainital",
    "location": "Uttarakhand",
    "image":
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb",
    "description":
        "Nainital is famous for lakes and beautiful hills.",
  },

  {
    "name": "Darjeeling",
    "location": "West Bengal",
    "image":
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
    "description":
        "Darjeeling is known for tea gardens and Kanchenjunga views.",
  },

  {
    "name": "Auli",
    "location": "Uttarakhand",
    "image":
        "https://images.unsplash.com/photo-1454496522488-7a8e488e8606",
    "description":
        "Auli is one of India's top skiing destinations.",
  },

  {
    "name": "Munnar",
    "location": "Kerala",
    "image":
        "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429",
    "description":
        "Munnar is famous for tea plantations and green valleys.",
  },

  {
    "name": "Kodaikanal",
    "location": "Tamil Nadu",
    "image":
        "https://images.unsplash.com/photo-1470770841072-f978cf4d019e",
    "description":
        "Kodaikanal is a peaceful hill station with forests and lakes.",
  },

  {
    "name": "Spiti Valley",
    "location": "Himachal Pradesh",
    "image":
        "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b",
    "description":
        "Spiti Valley is famous for cold deserts and mountain adventures.",
  },
];

// ==========================
// TEMPLES
// ==========================

final List<Map<String, String>> templePlaces = [

  {
    "name": "Golden Temple",
    "location": "Amritsar, India",
    "image":
        "https://images.unsplash.com/photo-1587474260584-136574528ed5",
    "description":
        "Golden Temple is the holiest Sikh shrine with golden architecture.",
  },

  {
    "name": "Kedarnath Temple",
    "location": "Uttarakhand",
    "image":
        "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
    "description":
        "Kedarnath Temple is one of the holiest temples dedicated to Shiva.",
  },

  {
    "name": "Badrinath Temple",
    "location": "Uttarakhand",
    "image":
        "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
    "description":
        "Badrinath Temple is a sacred Hindu pilgrimage destination.",
  },

  {
    "name": "Vaishno Devi",
    "location": "Jammu",
    "image":
        "https://images.unsplash.com/photo-1548013146-72479768bada",
    "description":
        "Vaishno Devi Temple is one of India's most visited temples.",
  },

  {
    "name": "Somnath Temple",
    "location": "Gujarat",
    "image":
        "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
    "description":
        "Somnath Temple is one of the twelve Jyotirlingas of Shiva.",
  },

  {
    "name": "Jagannath Temple",
    "location": "Odisha",
    "image":
        "https://images.unsplash.com/photo-1548013146-72479768bada",
    "description":
        "Jagannath Temple is famous for Rath Yatra festival.",
  },

  {
    "name": "Meenakshi Temple",
    "location": "Tamil Nadu",
    "image":
        "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
    "description":
        "Meenakshi Temple is famous for colorful South Indian architecture.",
  },

  {
    "name": "Konark Sun Temple",
    "location": "Odisha",
    "image":
        "https://images.unsplash.com/photo-1548013146-72479768bada",
    "description":
        "Konark Sun Temple is a UNESCO World Heritage Site.",
  },

  {
    "name": "Akshardham Temple",
    "location": "Delhi",
    "image":
        "https://images.unsplash.com/photo-1524492412937-b28074a5d7da",
    "description":
        "Akshardham Temple is known for stunning carvings and exhibitions.",
  },

  {
    "name": "Mahakaleshwar Temple",
    "location": "Ujjain",
    "image":
        "https://images.unsplash.com/photo-1548013146-72479768bada",
    "description":
        "Mahakaleshwar Temple is one of the famous Jyotirlingas.",
  },
];

// ==========================
// CITIES
// ==========================

final List<Map<String, String>> cityPlaces = [

  {
    "name": "Mumbai",
    "location": "Maharashtra",
    "image":
        "https://images.unsplash.com/photo-1529253355930-ddbe423a2ac7",
    "description":
        "Mumbai is India's financial capital famous for Bollywood.",
  },

  {
    "name": "Delhi",
    "location": "India",
    "image":
        "https://images.unsplash.com/photo-1587474260584-136574528ed5",
    "description":
        "Delhi is known for historical monuments and street food.",
  },

  {
    "name": "Bangalore",
    "location": "Karnataka",
    "image":
        "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429",
    "description":
        "Bangalore is India's tech hub with modern lifestyle.",
  },

  {
    "name": "Jaipur",
    "location": "Rajasthan",
    "image":
        "https://images.unsplash.com/photo-1477587458883-47145ed94245",
    "description":
        "Jaipur is called the Pink City and famous for forts.",
  },

  {
    "name": "Hyderabad",
    "location": "Telangana",
    "image":
        "https://images.unsplash.com/photo-1512453979798-5ea266f8880c",
    "description":
        "Hyderabad is famous for biryani and Charminar.",
  },

  {
    "name": "Kolkata",
    "location": "West Bengal",
    "image":
        "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429",
    "description":
        "Kolkata is known for culture, sweets and Howrah Bridge.",
  },

  {
    "name": "Chennai",
    "location": "Tamil Nadu",
    "image":
        "https://images.unsplash.com/photo-1491553895911-0055eca6402d",
    "description":
        "Chennai is famous for beaches and South Indian culture.",
  },

  {
    "name": "Pune",
    "location": "Maharashtra",
    "image":
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee",
    "description":
        "Pune is known for education and pleasant weather.",
  },

  {
    "name": "Ahmedabad",
    "location": "Gujarat",
    "image":
        "https://images.unsplash.com/photo-1512453979798-5ea266f8880c",
    "description":
        "Ahmedabad is famous for heritage and Gujarati food.",
  },

  {
    "name": "Goa",
    "location": "India",
    "image":
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    "description":
        "Goa is famous for beaches, nightlife and Portuguese culture.",
  },
];