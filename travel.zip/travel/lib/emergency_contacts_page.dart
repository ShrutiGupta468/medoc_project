import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

import 'emergency_data.dart';

class EmergencyContactsPage extends StatefulWidget {
  const EmergencyContactsPage({super.key});

  @override
  State<EmergencyContactsPage> createState() =>
      _EmergencyContactsPageState();
}

class _EmergencyContactsPageState
    extends State<EmergencyContactsPage> {

  List<Contact> contacts = [];

  @override
  void initState() {
    super.initState();
    loadContacts();
  }

  Future<void> loadContacts() async {

    if (await FlutterContacts.requestPermission()) {

      final data = await FlutterContacts.getContacts(
        withProperties: true,
      );

      setState(() {
        contacts = data;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),

      appBar: AppBar(
        title: const Text("Emergency Contacts"),
        centerTitle: true,
      ),

      body: contacts.isEmpty
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(

              padding: const EdgeInsets.all(16),

              itemCount: contacts.length,

              itemBuilder: (context, index) {

                final contact = contacts[index];

                final phone = contact.phones.isNotEmpty
                    ? contact.phones.first.number
                    : "";

                bool isSelected =
                    EmergencyData.emergencyNumbers
                        .contains(phone);

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius:
                        BorderRadius.circular(20),

                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                      ),
                    ],
                  ),

                  child: CheckboxListTile(

                    value: isSelected,

                    onChanged: (value) {

                      if (phone.isEmpty) return;

                      setState(() {

                        if (value == true) {

                          EmergencyData.emergencyNumbers
                              .add(phone);

                        } else {

                          EmergencyData.emergencyNumbers
                              .remove(phone);
                        }
                      });
                    },

                    secondary: CircleAvatar(
                      backgroundColor:
                          Colors.red.shade100,

                      child: const Icon(
                        Icons.person,
                        color: Colors.red,
                      ),
                    ),

                    title: Text(
                      contact.displayName,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    subtitle: Text(
                      phone.isEmpty
                          ? "No Number"
                          : phone,
                    ),
                  ),
                );
              },
            ),
    );
  }
}