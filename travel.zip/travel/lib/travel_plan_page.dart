import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TravelPlanPage extends StatefulWidget {
  const TravelPlanPage({super.key});

  @override
  State<TravelPlanPage> createState() =>
      _TravelPlanPageState();
}

class _TravelPlanPageState
    extends State<TravelPlanPage> {

  final destinationController =
      TextEditingController();

  final budgetController =
      TextEditingController();

  DateTime? selectedDate;

  bool isLoading = false;

  List<Map<String, dynamic>>
      plans = [];

  final supabase =
      Supabase.instance.client;

  @override
  void initState() {
    super.initState();

    fetchPlans();
  }

  // 🔷 FETCH USER PLANS
  Future<void> fetchPlans() async {

    final user =
        supabase.auth.currentUser;

    if (user == null) return;

    final data = await supabase
        .from('travel_plans')
        .select()
        .eq('user_id', user.id)
        .order(
          'created_at',
          ascending: false,
        );

    setState(() {
      plans =
          List<Map<String, dynamic>>
              .from(data);
    });
  }

  // 🔷 PICK DATE
  Future<void> pickDate() async {

    final picked =
        await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
      initialDate: DateTime.now(),
    );

    if (picked != null) {

      setState(() {
        selectedDate = picked;
      });
    }
  }

  // 🔷 ADD PLAN
  Future<void> addPlan() async {

    if (destinationController
            .text.isEmpty ||
        budgetController
            .text.isEmpty ||
        selectedDate == null) {
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) return;

      // 🔷 INSERT INTO DATABASE
      await supabase
          .from('travel_plans')
          .insert({

        'user_id': user.id,

        'destination':
            destinationController.text,

        'budget':
            budgetController.text,

        'travel_date':
            selectedDate!
                .toIso8601String(),
      });

      destinationController.clear();

      budgetController.clear();

      selectedDate = null;

      // 🔷 REFRESH DATA
      fetchPlans();

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Travel Plan Added",
          ),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content:
              Text(e.toString()),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFFF4F6FA),

      body: SafeArea(
        child: Column(
          children: [

            // 🔷 TOP DESIGN
            Container(
              padding:
                  const EdgeInsets.all(
                      25),

              decoration:
                  const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF5B86E5),
                    Color(0xFF36D1DC),
                  ],
                ),

                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(
                          35),

                  bottomRight:
                      Radius.circular(
                          35),
                ),
              ),

              child: const Column(
                crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                children: [

                  SizedBox(height: 10),

                  Text(
                    "Travel Planner ✈️",

                    style: TextStyle(
                      color:
                          Colors.white,

                      fontSize: 28,

                      fontWeight:
                          FontWeight
                              .bold,
                    ),
                  ),

                  SizedBox(height: 8),

                  Text(
                    "Plan your dream journey beautifully",

                    style: TextStyle(
                      color:
                          Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: ListView(
                padding:
                    const EdgeInsets.all(
                        16),

                children: [

                  // 🔷 DESTINATION
                  TextField(
                    controller:
                        destinationController,

                    decoration:
                        InputDecoration(
                      hintText:
                          "Destination",

                      prefixIcon:
                          const Icon(
                              Icons
                                  .location_on),

                      filled: true,

                      fillColor:
                          Colors.white,

                      border:
                          OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(
                                18),

                        borderSide:
                            BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 15),

                  // 🔷 BUDGET
                  TextField(
                    controller:
                        budgetController,

                    keyboardType:
                        TextInputType
                            .number,

                    decoration:
                        InputDecoration(
                      hintText:
                          "Budget",

                      prefixIcon:
                          const Icon(Icons
                              .currency_rupee),

                      filled: true,

                      fillColor:
                          Colors.white,

                      border:
                          OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(
                                18),

                        borderSide:
                            BorderSide.none,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 15),

                  // 🔷 DATE
                  GestureDetector(
                    onTap: pickDate,

                    child: Container(
                      padding:
                          const EdgeInsets
                              .all(18),

                      decoration:
                          BoxDecoration(
                        color:
                            Colors.white,

                        borderRadius:
                            BorderRadius.circular(
                                18),
                      ),

                      child: Row(
                        children: [

                          const Icon(Icons
                              .calendar_month),

                          const SizedBox(
                              width: 12),

                          Text(
                            selectedDate ==
                                    null
                                ? "Select Travel Date"
                                : "${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}",
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 20),

                  // 🔷 ADD BUTTON
                  ElevatedButton(
                    style:
                        ElevatedButton
                            .styleFrom(
                      backgroundColor:
                          Colors.blue,

                      padding:
                          const EdgeInsets
                              .symmetric(
                        vertical: 16,
                      ),

                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(
                                18),
                      ),
                    ),

                    onPressed:
                        isLoading
                            ? null
                            : addPlan,

                    child:
                        isLoading
                            ? const CircularProgressIndicator(
                                color:
                                    Colors.white,
                              )
                            : const Text(
                                "Add Travel Plan",

                                style:
                                    TextStyle(
                                  fontSize:
                                      16,

                                  color: Colors
                                      .white,
                                ),
                              ),
                  ),

                  const SizedBox(
                      height: 25),

                  // 🔷 TITLE
                  const Text(
                    "My Plans",

                    style: TextStyle(
                      fontSize: 20,

                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(
                      height: 15),

                  // 🔷 USER PLANS
                  ...plans.map(
                    (plan) {

                      final date =
                          DateTime.parse(
                        plan[
                            'travel_date'],
                      );

                      return Container(
                        margin:
                            const EdgeInsets
                                .only(
                          bottom: 14,
                        ),

                        padding:
                            const EdgeInsets
                                .all(18),

                        decoration:
                            BoxDecoration(
                          gradient:
                              LinearGradient(
                            colors: [
                              Colors.blue
                                  .shade400,

                              Colors.cyan
                                  .shade300,
                            ],
                          ),

                          borderRadius:
                              BorderRadius.circular(
                                  22),
                        ),

                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,

                          children: [

                            Text(
                              plan[
                                  "destination"],

                              style:
                                  const TextStyle(
                                color: Colors
                                    .white,

                                fontSize:
                                    20,

                                fontWeight:
                                    FontWeight
                                        .bold,
                              ),
                            ),

                            const SizedBox(
                                height:
                                    10),

                            Text(
                              "Budget: ₹${plan["budget"]}",

                              style:
                                  const TextStyle(
                                color: Colors
                                    .white,
                              ),
                            ),

                            Text(
                              "Date: ${date.day}/${date.month}/${date.year}",

                              style:
                                  const TextStyle(
                                color: Colors
                                    .white,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}