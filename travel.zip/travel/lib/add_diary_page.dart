import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import '../models/diary_model.dart';

class AddDiaryPage
    extends StatefulWidget {

  const AddDiaryPage({
    super.key,
  });

  @override
  State<AddDiaryPage>
      createState() =>
          _AddDiaryPageState();
}

class _AddDiaryPageState
    extends State<AddDiaryPage> {

  final titleController =
      TextEditingController();

  final descController =
      TextEditingController();

  bool isLoading = false;

  String imageUrl =
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e";

  // 🔷 GET CURRENT LOCATION
  Future<Position>
      determinePosition() async {

    bool serviceEnabled;
    LocationPermission
        permission;

    // 🔷 CHECK GPS
    serviceEnabled =
        await Geolocator
            .isLocationServiceEnabled();

    if (!serviceEnabled) {

      throw Exception(
        'Location services are disabled.',
      );
    }

    // 🔷 CHECK PERMISSION
    permission =
        await Geolocator
            .checkPermission();

    if (permission ==
        LocationPermission.denied) {

      permission =
          await Geolocator
              .requestPermission();

      if (permission ==
          LocationPermission.denied) {

        throw Exception(
          'Location permissions denied',
        );
      }
    }

    if (permission ==
        LocationPermission
            .deniedForever) {

      throw Exception(
        'Location permission permanently denied',
      );
    }

    return await Geolocator
        .getCurrentPosition();
  }

  // 🔷 SAVE ENTRY
  Future<void> saveEntry() async {

    if (titleController
            .text.isEmpty ||
        descController
            .text.isEmpty) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            "Please fill all fields",
          ),
        ),
      );

      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      // 🔷 GET LOCATION
      Position position =
          await determinePosition();

      // 🔷 GET CITY NAME
      List<Placemark> placemarks = [];

try {

  placemarks =
      await placemarkFromCoordinates(
    position.latitude,
    position.longitude,
  );

} catch (e) {

  print(e);
}


      Placemark place =
    placemarks.isNotEmpty
        ? placemarks.first
        : Placemark();

      String city =
    place.locality ?? "Unknown City";

String country =
    place.country ?? "Unknown Country";

String location =
    "$city, $country";

      // 🔷 CREATE ENTRY
      final entry =
          DiaryModel(

        title:
            titleController.text,

        description:
            descController.text,

        image: imageUrl,

        location: location,

        latitude:
            position.latitude,

        longitude:
            position.longitude,
      );

      Navigator.pop(
        context,
        entry,
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content:
              Text(e.toString()),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title:
            const Text(
          "Add Diary Entry",
        ),
      ),

      body: Padding(
        padding:
            const EdgeInsets.all(
                16),

        child: Column(
          children: [

            // 🔷 TITLE
            TextField(
              controller:
                  titleController,

              decoration:
                  const InputDecoration(
                labelText:
                    "Title",
              ),
            ),

            const SizedBox(
                height: 10),

            // 🔷 DESCRIPTION
            TextField(
              controller:
                  descController,

              decoration:
                  const InputDecoration(
                labelText:
                    "Description",
              ),

              maxLines: 3,
            ),

            const SizedBox(
                height: 20),

            // 🔷 SAVE BUTTON
            SizedBox(
              width:
                  double.infinity,

              height: 55,

              child:
                  ElevatedButton(
                onPressed:
                    isLoading
                        ? null
                        : saveEntry,

                child:
                    isLoading
                        ? const CircularProgressIndicator(
                            color:
                                Colors.white,
                          )
                        : const Text(
                            "Save Entry",
                          ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}