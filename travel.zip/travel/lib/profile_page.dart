import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'share_app_page.dart';
import 'update_profile_page.dart';
import 'app_updates_page.dart';
import 'preferences_page.dart';
import 'logout_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() =>
      _ProfilePageState();
}

class _ProfilePageState
    extends State<ProfilePage> {

  final supabase = Supabase.instance.client;

  Map<String, dynamic>? profileData;

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  // 🔷 LOAD PROFILE
  Future<void> loadProfile() async {

    try {

      final user =
          supabase.auth.currentUser;

      if (user == null) return;

      final data = await supabase
          .from('profiles')
          .select()
          .eq('id', user.id)
          .maybeSingle();

      setState(() {
        profileData = data;
        isLoading = false;
      });

    } catch (e) {

      debugPrint(
        "Profile Error: $e",
      );

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFFF4F6FA),

      body: SafeArea(

        child: isLoading
            ? const Center(
                child:
                    CircularProgressIndicator(),
              )

            : ListView(
                padding:
                    const EdgeInsets.all(16),

                children: [

                  // 🔷 PROFILE HEADER
                  Container(
                    padding:
                        const EdgeInsets.all(
                      20,
                    ),

                    decoration:
                        BoxDecoration(
                      gradient:
                          const LinearGradient(
                        colors: [
                          Color(0xFF6A5AE0),
                          Color(0xFF8E7CFF),
                        ],
                      ),

                      borderRadius:
                          BorderRadius.circular(
                        25,
                      ),
                    ),

                    child: Column(
                      children: [

                        // 🔷 PROFILE IMAGE
                        CircleAvatar(
                          radius: 45,

                          backgroundColor:
                              Colors.white,

                          backgroundImage:
                              profileData?[
                                              'avatar_url'] !=
                                          null &&
                                      profileData![
                                              'avatar_url']
                                          .toString()
                                          .isNotEmpty
                                  ? NetworkImage(
                                      "${profileData!['avatar_url']}?t=${DateTime.now().millisecondsSinceEpoch}",
                                    )
                                  : null,

                          child: profileData?[
                                          'avatar_url'] ==
                                      null ||
                                  profileData![
                                          'avatar_url']
                                      .toString()
                                      .isEmpty
                              ? const Icon(
                                  Icons.person,
                                  size: 40,
                                  color:
                                      Colors.grey,
                                )
                              : null,
                        ),

                        const SizedBox(
                            height: 12),

                        // 🔷 NAME
                        Text(
                          profileData?[
                                  'full_name'] ??
                              "No Name",

                          style:
                              const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),

                        const SizedBox(
                            height: 4),

                        // 🔷 EMAIL
                        Text(
                          profileData?[
                                  'email'] ??
                              "No Email",

                          style:
                              const TextStyle(
                            color:
                                Colors.white70,
                            fontSize: 14,
                          ),
                        ),

                        const SizedBox(
                            height: 15),

                        // 🔷 EDIT PROFILE BUTTON
                        ElevatedButton(
                          style:
                              ElevatedButton.styleFrom(
                            backgroundColor:
                                Colors.white,

                            foregroundColor:
                                Colors.deepPurple,

                            shape:
                                RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(
                                20,
                              ),
                            ),
                          ),

                          onPressed:
                              () async {

                            await Navigator.push(
                              context,

                              MaterialPageRoute(
                                builder:
                                    (context) =>
                                        const UpdateProfilePage(),
                              ),
                            );

                            // 🔷 REFRESH PROFILE
                            loadProfile();
                          },

                          child: const Text(
                            "Edit Profile",
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                      height: 20),

                  // 🔷 STATS
                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment
                            .spaceBetween,

                    children: const [

                      _StatCard(
                        title: "Trips",
                        value: "8",
                      ),

                      _StatCard(
                        title: "Cities",
                        value: "24",
                      ),

                      _StatCard(
                        title: "Km",
                        value: "32K",
                      ),
                    ],
                  ),

                  const SizedBox(
                      height: 25),

                  // 🔷 SETTINGS TITLE
                  const Text(
                    "Settings",

                    style: TextStyle(
                      fontSize: 18,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(
                      height: 12),

                  // 🔷 SHARE APP
                  _OptionTile(
                    icon: Icons.share,
                    title: "Share App",

                    onTap: () {

                      Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder:
                              (context) =>
                                  ShareAppPage(),
                        ),
                      );
                    },
                  ),

                  // 🔷 UPDATE PROFILE
                  _OptionTile(
                    icon: Icons.edit,
                    title:
                        "Update Profile",

                    onTap:
                        () async {

                      await Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder:
                              (context) =>
                                  const UpdateProfilePage(),
                        ),
                      );

                      loadProfile();
                    },
                  ),

                  // 🔷 APP UPDATES
                  _OptionTile(
                    icon:
                        Icons.system_update,

                    title:
                        "App Updates",

                    onTap: () {

                      Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder:
                              (context) =>
                                  AppUpdatesPage(),
                        ),
                      );
                    },
                  ),

                  // 🔷 PREFERENCES
                  _OptionTile(
                    icon: Icons.settings,
                    title: "Preferences",

                    onTap: () {

                      Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder:
                              (context) =>
                                  PreferencesPage(),
                        ),
                      );
                    },
                  ),

                  // 🔷 LOGOUT
                  _OptionTile(
                    icon: Icons.logout,

                    title: "Logout",

                    color: Colors.red,

                    onTap: () {

                      Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder:
                              (context) =>
                                  LogoutPage(),
                        ),
                      );
                    },
                  ),

                  const SizedBox(
                      height: 20),
                ],
              ),
      ),
    );
  }
}

// 🔷 STAT CARD
class _StatCard extends StatelessWidget {

  final String title;

  final String value;

  const _StatCard({
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      width: 100,

      padding:
          const EdgeInsets.all(12),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
          20,
        ),

        boxShadow: [

          BoxShadow(
            color:
                Colors.grey.shade200,

            blurRadius: 10,
          ),
        ],
      ),

      child: Column(
        children: [

          Text(
            value,

            style: const TextStyle(
              fontWeight:
                  FontWeight.bold,

              fontSize: 16,
            ),
          ),

          const SizedBox(height: 5),

          Text(
            title,

            style: const TextStyle(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}

// 🔷 OPTION TILE
class _OptionTile extends StatelessWidget {

  final IconData icon;

  final String title;

  final VoidCallback onTap;

  final Color? color;

  const _OptionTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      margin:
          const EdgeInsets.only(
        bottom: 10,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(
          20,
        ),

        boxShadow: [

          BoxShadow(
            color:
                Colors.grey.shade200,

            blurRadius: 8,
          ),
        ],
      ),

      child: ListTile(

        leading: Icon(
          icon,
          color:
              color ?? Colors.deepPurple,
        ),

        title: Text(title),

        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 16,
        ),

        onTap: onTap,
      ),
    );
  }
}