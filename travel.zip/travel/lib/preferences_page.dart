import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

class PreferencesPage extends StatefulWidget {
  const PreferencesPage({super.key});

  @override
  State<PreferencesPage> createState() =>
      _PreferencesPageState();
}

class _PreferencesPageState
    extends State<PreferencesPage> {

  bool notifications = true;
  bool darkMode = false;
  bool locationAccess = true;
  bool autoSync = false;

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadPreferences();
  }

  // 🔷 LOAD SAVED DATA
  Future<void> loadPreferences() async {
    final prefs =
        await SharedPreferences.getInstance();

    setState(() {
      notifications =
          prefs.getBool("notifications") ?? true;

      darkMode =
          prefs.getBool("darkMode") ?? false;

      locationAccess =
          prefs.getBool("locationAccess") ?? true;

      autoSync =
          prefs.getBool("autoSync") ?? false;

      isLoading = false;
    });
  }

  // 🔷 SAVE DATA
  Future<void> savePreferences() async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
        "notifications", notifications);

    await prefs.setBool(
        "darkMode", darkMode);

    await prefs.setBool(
        "locationAccess", locationAccess);

    await prefs.setBool(
        "autoSync", autoSync);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Preferences Saved"),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      backgroundColor: darkMode
          ? const Color(0xFF1E1E1E)
          : const Color(0xFFF5F6FA),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔷 HEADER
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(
                top: 70,
                bottom: 40,
              ),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF6A5AE0),
                    Color(0xFF8E7CFF),
                  ],
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(35),
                  bottomRight: Radius.circular(35),
                ),
              ),

              child: Column(
                children: [

                  // 🔷 BACK BUTTON
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 20,
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: const CircleAvatar(
                            backgroundColor:
                                Colors.white24,
                            child: Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 25),

                  // 🔷 SETTINGS ICON
                  Container(
                    padding:
                        const EdgeInsets.all(25),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.circular(
                              30),
                    ),
                    child: const Icon(
                      Icons.settings,
                      size: 65,
                      color: Color(0xFF6A5AE0),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Preferences",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  const Text(
                    "Customize your app experience",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // 🔷 SETTINGS CARD
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),
              child: Container(
                padding: const EdgeInsets.all(25),
                decoration: BoxDecoration(
                  color: darkMode
                      ? Colors.black54
                      : Colors.white,
                  borderRadius:
                      BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      blurRadius: 15,
                    ),
                  ],
                ),

                child: Column(
                  children: [

                    // 🔷 NOTIFICATIONS
                    _switchTile(
                      icon: Icons.notifications,
                      title: "Notifications",
                      value: notifications,
                      onChanged: (value) {
                        setState(() {
                          notifications = value;
                        });
                      },
                    ),

                    const SizedBox(height: 15),

                    // 🔷 DARK MODE
                    _switchTile(
                      icon: Icons.dark_mode,
                      title: "Dark Mode",
                      value: darkMode,
                      onChanged: (value) async {

                        setState(() {
                          darkMode = value;
                        });

                        // 🔷 APPLY TO WHOLE APP
                        MyApp.of(context)
                            ?.changeTheme(value);
                      },
                    ),

                    const SizedBox(height: 15),

                    // 🔷 LOCATION ACCESS
                    _switchTile(
                      icon: Icons.location_on,
                      title: "Location Access",
                      value: locationAccess,
                      onChanged: (value) {
                        setState(() {
                          locationAccess = value;
                        });
                      },
                    ),

                    const SizedBox(height: 15),

                    // 🔷 AUTO SYNC
                    _switchTile(
                      icon: Icons.sync,
                      title: "Auto Sync",
                      value: autoSync,
                      onChanged: (value) {
                        setState(() {
                          autoSync = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // 🔷 SAVE BUTTON
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),
              child: SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  style:
                      ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF6A5AE0),
                    shape:
                        RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(
                              18),
                    ),
                    elevation: 5,
                  ),
                  onPressed: savePreferences,
                  child: const Text(
                    "Save Preferences",
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // 🔷 CUSTOM SWITCH TILE
  Widget _switchTile({
    required IconData icon,
    required String title,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Row(
        children: [

          // 🔷 ICON
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius:
                  BorderRadius.circular(15),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF6A5AE0),
            ),
          ),

          const SizedBox(width: 15),

          // 🔷 TITLE
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 16,
                color: darkMode
                    ? Colors.white
                    : Colors.black,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),

          // 🔷 SWITCH
          Switch(
            value: value,
            activeColor:
                const Color(0xFF6A5AE0),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}