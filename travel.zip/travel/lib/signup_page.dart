import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() =>
      _SignupPageState();
}

class _SignupPageState
    extends State<SignupPage> {

  final _formKey = GlobalKey<FormState>();

  final TextEditingController
      nameController =
      TextEditingController();

  final TextEditingController
      emailController =
      TextEditingController();

  final TextEditingController
      phoneController =
      TextEditingController();

  final TextEditingController
      passwordController =
      TextEditingController();

  final TextEditingController
      confirmPasswordController =
      TextEditingController();

  bool obscurePassword = true;
  bool obscureConfirmPassword = true;

  bool isLoading = false;

  // 🔷 SUPABASE INSTANCE
  final supabase =
      Supabase.instance.client;

  // 🔷 SIGNUP FUNCTION
  Future<void> signupUser() async {

    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {

      final response =
          await supabase.auth.signUp(
        email:
            emailController.text.trim(),
        password:
            passwordController.text.trim(),

        // EXTRA USER DATA
        data: {
          'name':
              nameController.text.trim(),
          'phone':
              phoneController.text.trim(),
        },
      );

     final user = response.user;

if (user != null) {

  // INSERT DATA INTO PROFILES TABLE
  await supabase
      .from('profiles')
      .insert({

    'id': user.id,

    'name':
        nameController.text.trim(),

    'email':
        emailController.text.trim(),

    'phone':
        phoneController.text.trim(),
  });

  ScaffoldMessenger.of(context)
      .showSnackBar(
    const SnackBar(
      content: Text(
        "Account Created Successfully",
      ),
    ),
  );

  Navigator.pop(context);
}
    } on AuthException catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(e.message),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );

    } finally {

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F6FA),

      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔷 TOP HEADER
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(
                top: 80,
                bottom: 45,
              ),
              decoration:
                  const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF6A5AE0),
                    Color(0xFF8E7CFF),
                  ],
                ),
                borderRadius:
                    BorderRadius.only(
                  bottomLeft:
                      Radius.circular(40),
                  bottomRight:
                      Radius.circular(40),
                ),
              ),

              child: Column(
                children: [

                  Container(
                    padding:
                        const EdgeInsets.all(
                            22),
                    decoration:
                        BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius
                              .circular(28),
                    ),
                    child: const Icon(
                      Icons.person_add_alt_1,
                      size: 65,
                      color:
                          Color(0xFF6A5AE0),
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Create Account",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  const Text(
                    "Join and explore the world",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // 🔷 FORM
            Padding(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 20,
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [

                    _buildTextField(
                      controller:
                          nameController,
                      hint:
                          "Full Name",
                      icon:
                          Icons.person,
                      validator:
                          (value) {

                        if (value ==
                                null ||
                            value
                                .isEmpty) {
                          return "Name is required";
                        }

                        return null;
                      },
                    ),

                    const SizedBox(
                        height: 20),

                    _buildTextField(
                      controller:
                          emailController,
                      hint:
                          "Email Address",
                      icon: Icons.email,
                      validator:
                          (value) {

                        if (value ==
                                null ||
                            value
                                .isEmpty) {
                          return "Email is required";
                        }

                        if (!value.contains(
                            "@")) {
                          return "Enter valid email";
                        }

                        return null;
                      },
                    ),

                    const SizedBox(
                        height: 20),

                    _buildTextField(
                      controller:
                          phoneController,
                      hint:
                          "Phone Number",
                      icon: Icons.phone,
                      keyboardType:
                          TextInputType
                              .phone,
                      validator:
                          (value) {

                        if (value ==
                                null ||
                            value
                                .isEmpty) {
                          return "Phone number is required";
                        }

                        if (value.length <
                            10) {
                          return "Enter valid phone number";
                        }

                        return null;
                      },
                    ),

                    const SizedBox(
                        height: 20),

                    _buildPasswordField(),

                    const SizedBox(
                        height: 20),

                    _buildConfirmPasswordField(),

                    const SizedBox(
                        height: 35),

                    // 🔷 SIGNUP BUTTON
                    SizedBox(
                      width:
                          double.infinity,
                      height: 58,
                      child:
                          ElevatedButton(
                        style:
                            ElevatedButton
                                .styleFrom(
                          backgroundColor:
                              const Color(
                                  0xFF6A5AE0),
                          shape:
                              RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(
                                    18),
                          ),
                          elevation: 5,
                        ),
                        onPressed:
                            isLoading
                                ? null
                                : signupUser,

                        child:
                            isLoading
                                ? const CircularProgressIndicator(
                                    color:
                                        Colors.white,
                                  )
                                : const Text(
                                    "Create Account",
                                    style:
                                        TextStyle(
                                      fontSize:
                                          18,
                                      color: Colors
                                          .white,
                                      fontWeight:
                                          FontWeight
                                              .bold,
                                    ),
                                  ),
                      ),
                    ),

                    const SizedBox(
                        height: 25),

                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment
                              .center,
                      children: [

                        const Text(
                          "Already have an account? ",
                        ),

                        GestureDetector(
                          onTap: () {
                            Navigator.pop(
                                context);
                          },
                          child:
                              const Text(
                            "Login",
                            style:
                                TextStyle(
                              color: Color(
                                  0xFF6A5AE0),
                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                        height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔷 TEXT FIELD
  Widget _buildTextField({
    required TextEditingController
        controller,
    required String hint,
    required IconData icon,
    required String? Function(
            String?)
        validator,
    TextInputType keyboardType =
        TextInputType.text,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hint,
          prefixIcon: Icon(
            icon,
            color:
                const Color(0xFF6A5AE0),
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.all(20),
        ),
      ),
    );
  }

  // 🔷 PASSWORD FIELD
  Widget _buildPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
          ),
        ],
      ),
      child: TextFormField(
        controller:
            passwordController,
        obscureText:
            obscurePassword,
        validator: (value) {

          if (value == null ||
              value.isEmpty) {
            return "Password is required";
          }

          if (value.length < 6) {
            return "Password must be at least 6 characters";
          }

          return null;
        },
        decoration: InputDecoration(
          hintText: "Password",
          prefixIcon: const Icon(
            Icons.lock,
            color:
                Color(0xFF6A5AE0),
          ),
          suffixIcon: IconButton(
            onPressed: () {
              setState(() {
                obscurePassword =
                    !obscurePassword;
              });
            },
            icon: Icon(
              obscurePassword
                  ? Icons
                      .visibility_off
                  : Icons.visibility,
            ),
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.all(20),
        ),
      ),
    );
  }

  // 🔷 CONFIRM PASSWORD
  Widget _buildConfirmPasswordField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 10,
          ),
        ],
      ),
      child: TextFormField(
        controller:
            confirmPasswordController,
        obscureText:
            obscureConfirmPassword,
        validator: (value) {

          if (value == null ||
              value.isEmpty) {
            return "Confirm password is required";
          }

          if (value !=
              passwordController
                  .text) {
            return "Passwords do not match";
          }

          return null;
        },
        decoration: InputDecoration(
          hintText:
              "Confirm Password",
          prefixIcon: const Icon(
            Icons.lock_outline,
            color:
                Color(0xFF6A5AE0),
          ),
          suffixIcon: IconButton(
            onPressed: () {
              setState(() {
                obscureConfirmPassword =
                    !obscureConfirmPassword;
              });
            },
            icon: Icon(
              obscureConfirmPassword
                  ? Icons
                      .visibility_off
                  : Icons.visibility,
            ),
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.all(20),
        ),
      ),
    );
  }
}