import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class LeafletMapWidget extends StatelessWidget {
  const LeafletMapWidget({super.key});

  @override
  Widget build(BuildContext context) {

    return FlutterMap(
      options: MapOptions(
        initialCenter: const LatLng(30.7333, 76.7794),
        initialZoom: 13,
      ),

      children: [

        TileLayer(
          urlTemplate:
              "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          userAgentPackageName: 'com.example.trava',
        ),

        MarkerLayer(
          markers: [
            Marker(
              point: const LatLng(30.7333, 76.7794),
              width: 80,
              height: 80,
              child: const Icon(
                Icons.location_on,
                color: Colors.red,
                size: 40,
              ),
            ),
          ],
        ),
      ],
    );
  }
}