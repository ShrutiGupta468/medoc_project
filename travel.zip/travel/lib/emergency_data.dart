class EmergencyData {
  static List<String> emergencyNumbers = [];
}