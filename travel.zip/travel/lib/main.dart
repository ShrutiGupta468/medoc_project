import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 🔷 Initialize Supabase
  await Supabase.initialize(
    url: 'https://jgdoluucdegfhdoikodq.supabase.co',
   anonKey:
'sb_publishable_tdYZ5_xNkMutY9N-2nqSCw_h2QV3Ubx',
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  // 🔷 GLOBAL ACCESS
  static _MyAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>();

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  bool darkMode = false;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadTheme();
  }

  // 🔷 LOAD SAVED THEME
  Future<void> loadTheme() async {
    final prefs =
        await SharedPreferences.getInstance();

    setState(() {
      darkMode =
          prefs.getBool("darkMode") ?? false;

      isLoading = false;
    });
  }

  // 🔷 CHANGE THEME
  Future<void> changeTheme(bool value) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool("darkMode", value);

    setState(() {
      darkMode = value;
    });
  }

  @override
  Widget build(BuildContext context) {

    if (isLoading) {
      return const MaterialApp(
        home: Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My App',

      // 🔷 LIGHT THEME
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.deepPurple,
        fontFamily: 'Poppins',
        scaffoldBackgroundColor:
            const Color(0xFFF5F6FA),
      ),

      // 🔷 DARK THEME
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Poppins',
        scaffoldBackgroundColor:
            const Color(0xFF121212),

        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
        ),
      ),

      // 🔷 APPLY THEME
      themeMode:
          darkMode
              ? ThemeMode.dark
              : ThemeMode.light,

      home: const SplashScreen(),
    );
  }
}